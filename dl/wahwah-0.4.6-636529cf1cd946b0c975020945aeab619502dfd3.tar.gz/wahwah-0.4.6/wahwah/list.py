from __future__ import absolute_import, unicode_literals

import logging
import time

from . import REFRESH_MAX_RATE
from .station import WahwahStation


logger = logging.getLogger('wahwah.list')


class WahwahUserList(set):
    def __init__(self, outer, name):
        self.data = []
        self.outer = outer
        self.last_conn = 0
        self.name = name
        self._raw_data = None

    def __get_stations(self):
        time_stamp = time.time()
        self.outer._check_status()
        if self.last_conn + REFRESH_MAX_RATE > time_stamp:
            return
        self.last_conn = time_stamp
        self._raw_data = self.outer.wahwah.request("GET", "/api/1.0/users/%s/%s/" % (
                                  self.outer.user_id, self.name))
        stations = list()
        for station in self._raw_data:
            sta = WahwahStation(self.outer)
            intersection = self.outer._station_pool & set([sta])
            if intersection:
                sta = intersection[0]
            else:
                sta._parse_station(station)
            stations.append(sta)
        self.data = stations

    def __del_station(self, elem):
        if not self.outer.user_id:
            return
        self.last_conn = 0
        data = self.outer.wahwah.request("DELETE", "/api/1.0/users/%s/%s/%s/" % (
                                  self.outer.user_id, self.name, elem.id))
        logger.debug("Deleted %r station from %r. %r", elem , self.name, data)

    def __add_station(self, elem):
        if not self.outer.user_id:
            return
        self.last_conn = 0
        data = self.outer.wahwah.request("POST", "/api/1.0/users/%s/%s/" % (
                                  self.outer.user_id, self.name),
                                  body='{"id": "%s"}' % elem.id)
        logger.debug("Added %r station to %r. %r", elem, self.name, data)

    def __repr__(self):
        self.__get_stations()
        return repr(self.data)

    def add(self, elem):
        self.__get_stations()
        if elem in self.data:
            return
        self.__add_station(elem)

    def clear(self):
        self.__get_stations()
        """Erase all the elements"""
        for sta in self.data:
            self.__del_station(sta)

    def discard(self, elem):
        """Discard an element if present"""
        try:
            self.__del_station(elem)
        except Exception:
            pass

    def remove(self, elem):
        self.__get_stations()
        if not elem in self.data:
            raise KeyError
        self.__del_station(elem)

    def __iter__(self):
        self.__get_stations()
        return self.data.__iter__()

    def __contains__(self, elem):
        self.__get_stations()
        return elem in self.data

    def __len__(self):
        self.__get_stations()
        return len(self.data)

    def pop(self):
        self.__get_stations()
        return self.data.pop()

    def copy(self):
        self.__get_stations()
        return self.data[:]
#    def __le__(self)
#    def __lt__(self)
#    def __eq__(self)
#    def __ne__(self)
#    def __gt__(self)
#    def __ge__(self)
#    def __and__(self)
#    def __or__(self)
#    def __sub__(self)
#    def __xor__(self)
#    def isdisjoint(self)
#    def __ior__(self)
#    def __iand__(self)
#    def __ixor__(self)
#    def __isub__(self)

    def __call__(self):
        print "Called!"
        return self.data[:]

    def __get__(self, *args, **kwargs):
        print "get(%s,%s)" % (repr(args), repr(kwargs))
        self.__get_stations()
        return self.data

    def __getitem__(self, key):
        self.__get_stations()
        return self.data[key]
