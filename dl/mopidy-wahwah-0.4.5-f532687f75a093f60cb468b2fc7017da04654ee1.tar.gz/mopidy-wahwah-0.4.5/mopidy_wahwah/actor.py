from __future__ import unicode_literals, absolute_import

import pykka
import logging

from mopidy.backends.base import Backend

from .client import WahwahClient
from .library import WahwahLibraryProvider
from .tracklist import WahwahTracklistProvider
from .playback import WahwahPlaybackProvider
from .playlists import WahwahPlaylistsProvider
from .metadata import WahwahMetadataProvider


logger = logging.getLogger("mopidy.backends.wahwah")


class WahwahBackend(pykka.ThreadingActor, Backend):
    def __init__(self, config, audio):
        super(WahwahBackend, self).__init__()
        self.config = config
        cli = {}

        cli['backend_uri'] = config['wahwah']['host']
        cli['backend_id'] = config['wahwah']['facebook_id']
        cli['allow_unregistered'] = config['wahwah']['allow_unregistered']
        if 'auth_token' in config['wahwah']:
            cli['auth_token'] = config['wahwah']['auth_token']

        if 'rpc' in config:
            if 'user' in config['rpc'] and 'password' in config['rpc']:
                cli['rpc_user'] = config['rpc']['user']
                cli['rpc_pass'] = config['rpc']['password']
            else:
                logger.warning("RPC user and password is not set!")
        else:
            logger.warning("RPC is not set!")

        self.wahwah = WahwahClient(**cli)
        self.library = WahwahLibraryProvider(self)
        self.tracklist = WahwahTracklistProvider(self)
        self.playback = WahwahPlaybackProvider(audio, self)
        self.playlists = WahwahPlaylistsProvider(self)
        self.metadata = WahwahMetadataProvider(self)

        self.uri_schemes = ['wahwah']
