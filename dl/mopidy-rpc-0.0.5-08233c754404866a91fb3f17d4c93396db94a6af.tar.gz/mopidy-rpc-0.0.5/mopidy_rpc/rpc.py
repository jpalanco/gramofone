#!/usr/bin/python

from __future__ import unicode_literals

import logging

from mopidy import core, models
from mopidy import config as config_lib
from mopidy import commands, ext
from mopidy.utils import log, path, process
from mopidy.utils import path

from mopidy.utils import jsonrpc
import json


import urlparse
import sys

import pkg_resources
import ConfigParser


logger = logging.getLogger('mopidy.frontends.rpc')

#This class will handles any incoming request from
#the browser 
class RPCHandler():

    def __init__(self, request, client_address, server):
        self.request = request
        self.client_address = client_address
        self.server = server
        self.setup()
        try:
            self.handle()
        finally:
            self.finish()

    def setup(self):
        self.jsonrpc = self.server.jsonrpc
        self.valid_methods = ['core.metadata.config','core.metadata.raise_event','core.metadata.get','core.playback.get_state','core.playback.set_mute','core.playback.get_mute', 'core.playback.stop', 'core.playback.pause', 'core.playback.resume', 'core.playback.on_external_mute']
        self.invalid_response = json.dumps({
            "jsonrpc": "2.0", 
            "id": 1, 
            "error": {
                "message": "Method not found", 
                "code": -32601, 
                "data": "Method not listed as available"
                }
            })

    def handle(self):
        try:
            self.data = self.request.recv(1024).strip()
            logger.debug("RPC Request: "+self.data)
            rpc_command = json.loads(self.data)
            if rpc_command["method"] == "core.playback.set_mute":
                logger.debug("Translating method from 'set_mute' to 'on_external_mute'")
                rpc_command["method"] = "core.playback.on_external_mute"
                self.data = json.dumps(rpc_command)

            if rpc_command["method"] in self.valid_methods:
                response = self.jsonrpc.handle_json(self.data)

                if response:
                    logger.debug("RPC Response: "+response)
                    self.request.send(response)
                else:
                    logger.error("RPC No Response Except")
                    self.request.send(self.invalid_response)
            else:
                logger.error("RPC Response Not Listed")
                self.request.send(self.invalid_response)
        except:
            logger.error("RPC Response Except: "+str(e))
            self.request.send(self.invalid_response)




    def finish(self):
        pass
