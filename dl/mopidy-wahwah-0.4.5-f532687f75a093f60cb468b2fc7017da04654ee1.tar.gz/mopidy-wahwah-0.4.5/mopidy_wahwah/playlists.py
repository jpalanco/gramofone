from __future__ import unicode_literals, absolute_import

import logging

from mopidy.backends.base import BasePlaylistsProvider
from mopidy.models import Playlist


logger = logging.getLogger("mopidy.backends.wahwah")


class WahwahPlaylistsProvider(BasePlaylistsProvider):
    def __init__(self, *args, **kwargs):
        super(WahwahPlaylistsProvider, self).__init__(*args, **kwargs)
        self._playlists = [Playlist(uri="wahwah:user:favorites",
                                    name="Favorites by Wahwah",
                                    tracks=[]),
                           Playlist(uri="wahwah:user:stations",
                                    name="Stations by Wahwah",
                                    tracks=[])]

    def create(self, name):
        logger.debug("create('%s')" % name)
        return None

    def delete(self, uri):
        logger.debug("delete('%s')" % uri)
        return None

    def lookup(self, uri):
        logger.debug("lookup('%s')" % uri)
        if uri == "wahwah:user:favorites":
            self._playlists[0] = self.backend.wahwah.get_user_favorites()
            return self._playlists[0]
        elif uri == "wahwah:user:stations":
            self._playlists[1] = self.backend.wahwah.get_user_stations()
            return self._playlists[1]
        return None

    def refresh(self):
        logger.debug("refresh()")
        return None

    def save(self, playlist):
        logger.debug("save(\"%s\")" % repr(playlist))
        if playlist.uri == "wahwah:user:favorites":
            self.backend.wahwah.update_favorites(playlist)
            self._playlists[0] = self.backend.wahwah.get_user_favorites()
            return self._playlists[0]
        elif playlist.uri == "wahwah:user:stations":
            self.backend.wahwah.update_stations(playlist)
            self._playlists[1] = self.backend.wahwah.get_user_stations()
            return self._playlists[1]

        return None
