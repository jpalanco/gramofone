from __future__ import unicode_literals

import nose

nose.core.main()
