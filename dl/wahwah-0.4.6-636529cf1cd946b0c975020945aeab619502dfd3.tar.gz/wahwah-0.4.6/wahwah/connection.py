from __future__ import absolute_import, unicode_literals

import logging
from httplib import HTTPConnection, BadStatusLine, CannotSendHeader, CannotSendRequest, ResponseNotReady, \
    error
from socket import gaierror, timeout
import socket
from threading import Lock, Thread, Timer
import time
import re
from wahwah.exceptions import WahwahException, WahwahNotConnected,\
    WahwahStatusError, WahwahTimeout
try:
    import simplejson as json
    from simplejson.decoder import JSONDecodeError
except ImportError:
    import json
    JSONDecodeError = ValueError

logger = logging.getLogger('wahwah.connection')


class WahwahConnection(HTTPConnection):
    """ Handles all the connection to Wahwah API
    It is supposed to be transparent to the Client, in the means that it
    won't touch the data, or even read the response. It inherits from
    :class:`HTTPConnection`, and supersedes some of it's methods.

    It is in charge of making the cookie handling for keeping the session, and
    also careful in saving in disc the auth_token
    """
    def __init__(self, *args, **kwargs):
        HTTPConnection.__init__(self, *args, **kwargs)
        self.debuglevel = 0
        self.lock = Lock()
        self.__sessionid = {"value": None, "age": None}
        self.__headers = {'Content-Type': "application/json"}
        self.addres_info = None
        self.addres_info_thread = None

    def reset(self):
        self.__sessionid = {"value": None, "age": None}

    def getaddinfo(self):
        try:
            self.addres_info = socket.getaddrinfo(self.host, self.port, 0, 0, socket.SOL_TCP)
        except:
            pass

    def kill_getaddinfo_thread(self):
        self.addres_info_thread._Thread__stop()

    def connect(self):
        try:
            self.addres_info_thread = Thread(name='getaddinfo_thread', target=self.getaddinfo)
            Timer(self.timeout, self.kill_getaddinfo_thread).start()
            self.addres_info_thread.start()
            self.addres_info_thread.join()

            if self.addres_info:
                _, _, _, _, sa = self.addres_info[0]
                self.sock = socket.create_connection(sa, self.timeout, self.source_address)
            else:
                raise WahwahNotConnected()

            if self._tunnel_host:
                self._tunnel()
        except Exception as e:
            logger.debug("Connection failed when trying to connect!")
            raise WahwahNotConnected(e)

    def request(self, *args, **kwargs):
        self.lock.acquire()
        while True:
            try:
                self._request(*args, **kwargs)
                response = self.getresponse()
                break
            except (WahwahException, WahwahNotConnected):
                self.close()
                self.lock.release()
                raise
            except (BadStatusLine, ResponseNotReady, error):
                logger.debug("Connection closed, restarting connection and retrying.")
                self.close()
                continue
            except (CannotSendHeader, CannotSendRequest):
                logger.warning("Previous response wasn't read, restarting connection")
                self.close()
                continue
            except (timeout) as e:
                logger.warning('Request timeout!!!')
                self.lock.release()
                raise WahwahTimeout(self.timeout, e)
            except (gaierror) as e:
                self.close()
                logger.warning("Failed request(%r,%r) for connectivity problems", args, kwargs)
                self.lock.release()
                raise WahwahNotConnected(e)
            except (Exception) as e:
                self.close()
                self.lock.release()
                logger.error("Failed request(%r,%r) for %r", args, kwargs, e)
                logger.warning('Not handled exception, putting it inside WahwahException')
                raise WahwahException(e)
        self.lock.release()
        ret = {}
        try:
            data = response.read()
        except Exception as e:
            logger.exception("Got exception on socket read: %r", e)
            logger.debug('Retrying to read')
            try:
                data = response.read()
            except Exception as e:
                logger.error('Error definitelly happening')
                raise WahwahNotConnected(e)
        logger.debug("\tRequest: request(%r,%r)\n\tResponse:\n\t\tStatus\t%r\n\t\tHeaders\t%r\n\t\tBody\t%r",
                     args, kwargs, response.status, response.getheaders(), data)
        if response.status < 200 or response.status > 299:  # We don't handle redirects
            logger.warning("Status for request(%r,%r) is %d", args, kwargs, response.status)
            raise WahwahStatusError(response.status, 'Status must be in 200-299 range', data)
        try:
            ret = json.loads(data)
        except (ValueError, JSONDecodeError):
            logger.error("Error decoding data: %r", data)
            ret = {}
        return ret


    def _request(self, *args, **kwargs):
        """ Adds a 'Content-Type: application/json' header to POST requests. It
        also adds the sessionid cookie if valid.
        """
        if not "headers" in kwargs:
            kwargs['headers'] = dict()
        if args[0] == "POST":
            kwargs['headers'].update(self.__headers)

        if self.__sessionid['value'] and \
           self.__sessionid['age'] > time.time():
            cookies = "sessionid=" + self.__sessionid['value']
            kwargs['headers']['Cookie'] = cookies

        logger.debug("Sending request [%r] timeout=%r with %r and %r", time.time(), self.timeout, args, kwargs)
        return HTTPConnection.request(self, *args, **kwargs)

    def getresponse(self):
        """ Appart from handling the response as :class:`HTTPConnection` does,
        it also checks for the cookie and updates it.
        """
        logger.debug("Trying to get request at %r", time.time())
        response = HTTPConnection.getresponse(self)
        logger.debug("Got request at %r", time.time())
        cookie = response.getheader('Set-Cookie')
        if cookie:
            logger.debug("Getting a cookie " + cookie)
            self.__sessionid['value'] = re.search(
                r'.*sessionid=(\")?(?P<id>.*)(?(1)\1).*', cookie).group(2)
            self.__sessionid['age'] = int(re.search(
                r'.*Max-Age=(?P<age>\d*).*', cookie).group(1)) + time.time()
            logger.debug("Got cookie: '%s'", self.__sessionid['value'])
        return response