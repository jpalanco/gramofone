from __future__ import absolute_import, unicode_literals

import logging
import time
from . import REFRESH_MAX_RATE, MUSIC_STORE_TIMEOUT
from urlparse import urlparse
from threading import RLock, Event
from wahwah.exceptions import WahwahStatusError, WahwahException
from httplib import HTTPConnection, HTTPSConnection
try:
    import simplejson as json
except ImportError:
    import json

logger = logging.getLogger('wahwah.station')



class WahwahStation(object):
    """ A wahwah station that makes available all the functionality relative to
        an station.
    """

    def __eq__(self, other):
        try:
            return self.id == other.id and self.name == other.name
        except AttributeError:
            return False

    def __init__(self, cli):
        self.__client = cli
        self.__wahwah = cli.wahwah
        self._first_time = True
        self._last_conn = 0
        self._settings = {}
        self._data = {}
        self.__many_errors = 0
        self.__timeout_errors = 0
        self.id = ''
        self.name = ''
        self.session_id = ''
        self._artist_id = ''

        self.limit = WahwahStatusError(status=406)
        self._skip_limit = {
                'method': 'regular',
                'skip_limit': 5,
                'skip_count': 0,
                'next_time': 0,
            }
        self.exception = WahwahException("Initial exception, if raised, something wrong")
        self._request_counter = 0
        self._track_counter = 0
        self._track_queue = {}
        self._job_queue = {}
        self.__queue_lock = RLock()
        self._track_queue_updated = Event()

    def __repr__(self):
        return "<" + self.name.replace(" ", "-") + "@" + self.id + ">"

    def _create_station(self, id):
        """
        The function that creates the station from the API. It transforms
        the data received from the API to station object's attributes, and
        saves the received object in :attr:`_data`.
        """
        data = self.__wahwah.request("POST", "/api/1.0/stations/", body=id)
        self._parse_station(data)
        logger.debug("Received /stations/ response for %r", self.name)

    def _parse_station(self, data):
        """
        Parses the data returned for an station without creating it, with
        the aim of creating the station as a placeholder that will be created
        and initialized just in case of using it, saving this way a call to
        the API
        """
        self._data.update(data)
        self.id = data.get('id', self.id)
        self.name = data.get('name', self.name)
        self.session_id = data.get('station_session_id', self.session_id)
        self._artist_id = data.get('artist_id', self._artist_id)

    def get_track(self, had_error=False, duration=0):
        """
        Queries the API either for the first song or the next ones. If
        no radio station, creates the radio itself.
        """
        logger.debug("Checking for limit")
        if (not had_error) and self._get_skip_limit():
            raise self.limit
        self._add_job(self._track_counter, (had_error, duration))
        self.__client._event_queue.set()
        try:
            with self.__queue_lock:
                num = sorted(self._track_queue)[0]
                ret = self._track_queue.pop(num)
        except IndexError:
            logger.debug('No tracks in queue, waiting for job to be done')
            self._track_queue_updated.clear()
            self._track_queue_updated.wait(timeout=5)
            self._track_queue_updated.clear()
            try:
                with self.__queue_lock:
                    num = sorted(self._track_queue)[0]
                    ret = self._track_queue.pop(num)
            except IndexError:
                return {}
        self._track_counter = num
        logger.debug('Gathered track index %r', num)
        if self._job_queue:
            self.__client._event_queue.set()
        return ret

    def _first(self):
        data = self.__wahwah.request("GET", "/api/1.0/stations/%s/%s/" % (self.id,
                              self.session_id) + "?action=first&" +
                              "audio_format=mp3&client_id=1355&playid=" +
                              str(self.__client.play_id))
        return data

    def _next(self, duration):
        data = self.__wahwah.request("GET", "/api/1.0/stations/%s/%s/" % (self.id,
                              self.session_id) + "?action=next&" +
                              "audio_format=mp3&client_id=1355&playid=" +
                              str(self.__client.play_id) + "&duration=" +
                              str(int(duration)))
        return data

    def _error(self, duration):
        data = self.__wahwah.request("GET", "/api/1.0/stations/%s/%s/" % (self.id,
                              self.session_id) + "?action=error&" +
                              "audio_format=mp3&client_id=1355&playid=" +
                              str(self.__client.play_id) + "&duration=" +
                              str(int(duration)))
        return data

    def _job_executor(self):
        for job in sorted(self._job_selector()):
            had_error, duration = self._job_queue.pop(job)
            logger.debug("Doing job %r = (%r, %r)", job, had_error, duration)
            res = self._process_gather_track(job, duration, had_error)
            if not res:
                continue
            tracks = self._process_tracks(res)
            for num, track in tracks.iteritems():
                if not self._validate_track(num, track):
                    continue
                with self.__queue_lock:
                    ret = self._update_track_queue(num, track)
                if ret:
                    self._track_queue_updated.set()

    def _process_gather_track(self, job, duration, had_error):
        try:
            if job == 0:
                self._first_time = True
            res = self._gather_track(duration, had_error)
        except WahwahStatusError as e:
            if e.status == 406:
                logger.warning('Seems like we got to the skip limit!')
                self.limit = e
            else:
                logger.warning('Got status %s', e.status)
            self._set_skip_limit(exception=e)
            return None
        except Exception as e:
            logger.exception("Got this amazing exception in backend thread: %r", e)
            self.exception = e
            return None
        self._set_skip_limit(res)
        return res

    def _process_tracks(self, gathered_tracks):
        tracks = {}
        tmp = self._response_parse_to_tracks(gathered_tracks)
        for n, t in enumerate(tmp, start=self._request_counter):
            tracks[n] = t
        return tracks

    def _validate_track(self, num, track):
        ret = self._check_uri(track['uri'])
        if ret:
            return True
        self._add_job(num, (True, 0))
        return False

    def _add_job(self, pos, job):
        if pos in self._job_queue:
            logger.debug('Job already exists %r - %r', pos, self._job_queue[pos])
            return
        logger.debug('Enqueueing job %r - %r', pos, job)
        self._job_queue[pos] = job

    def _job_selector(self):
        to_do = {}
        for key in sorted(self._job_queue.iterkeys()):
            if key <= self._track_counter:
                to_do[key] = self._job_queue[key]
        return to_do

    def _check_uri(self, track_uri):
        """
        Checks if a uri is valid or not.
        """
        res = None
        logger.debug('Checking uri %r', track_uri)

        if track_uri.endswith('not_valid_url'):
            logger.debug('Not valid url as stated with wahwah')
            return False
        uri = urlparse(track_uri)
        conn = self._get_connection_to_provider(uri)
        if not conn:
            return False
        try:
            conn.request('HEAD', uri.path + '?' + uri.query, headers={
                'User-Agent': 'Wahwah',
                'Accept': '*/*'})
            res = conn.getresponse()
        except Exception as e:
            conn.close()
            logger.debug('Not valid url due to exception %r on check', e)
            return False
        if getattr(res, 'status', 408) != 200:
            logger.debug('Not valid, status is %r', getattr(res, 'status', 408))
            return False
        logger.debug('Track OK')
        return True

    def _gather_track(self, duration, had_error):
        """
        This will get sure to take whatever it needs to.
        """
        if not self.session_id:
            logger.debug("Creating the station now.")
            self._create_station('{"station_id": "%s"}' % self.id)
        self._request_counter += 1
        if self._first_time:
            self._first_time = False
            ret = self._first()
        elif had_error:
            ret = self._error(duration=duration)
        else:
            ret = self._next(duration=duration)
        return ret

    def _get_connection_to_provider(self, uri):
        if uri.scheme == 'http':
            conn = HTTPConnection(uri.netloc, timeout=MUSIC_STORE_TIMEOUT)
        elif uri.scheme == 'https':
            conn = HTTPSConnection(uri.netloc, timeout=MUSIC_STORE_TIMEOUT)
        else:
            logger.warning('Not valid scheme: %s', uri.scheme)
            return False
        return conn

    def _response_parse_to_tracks(self, res):
        """
        Gets a response and converts it to the data needed for songs
        """
        tracks = [dict()]
        tracks[0]['title'] = res['track']['title']
        tracks[0]['uri'] = res['track']['url']
        tracks[0]['length'] = res['track']['duration']
        tracks[0]['art_slug'] = res['track']['artist_slug']
        tracks[0]['art_name'] = res['track']['artist']
        tracks[0]['alb_name'] = res['track']['album']

        for t in res['next_tracks']:
            track = dict()
            track['title'] = t.get('title', '')
            track['uri'] = t.get('url', '')
            track['length'] = t.get('duration', 0)
            track['art_slug'] = t.get('artist_slug', '')
            track['art_name'] = t.get('artist', '')
            track['alb_name'] = t.get('album', '')
            track['length'] = t.get('duration', '')
            tracks.append(track)
        return tracks

    def _update_track_queue(self, pos, track):
        try:
            first, t = sorted(self._track_queue.iteritems())[0]
        except IndexError:
            # +1 because its what it is playing atm, so next is the desired
            first, t = (self._track_counter + 1, {'title': 'None'})

        logger.debug('Reference track <%r@%r>', first, t['title'])
        logger.debug('Processing track <%r@%r>', pos, track['title'])
        if not first <= pos:
            logger.debug('Track already used')
            return False
        logger.debug('Update <%r@%r> -> <%r@%r> ',
                     pos,
                     self._track_queue.get(pos, {}).get('title', None),
                     pos,
                     track['title'])
        logger.debug("%s to %s",
                     self._track_queue.get(pos, {}).get('uri', None),
                     track['uri'])
        self._track_queue[pos] = track
        return True

    def _set_skip_limit(self, response=None, exception=False):
        """
        Takes a request as input, parses it, and saves that value
        for future gets
        """
        if exception:
            self._skip_limit['method'] = 'on-demand'
            return
        if not hasattr(response.get('meta'), 'get'):
            self._skip_limit['method'] = 'on-demand'
            self._skip_limit['next_time'] = time.time() + response.get('track', {}).get('duration', 0)
            return
        self._skip_limit = {
                'method': 'regular',
                'skip_limit': response.get('meta', {}).get('skip_limit', 0),
                'skip_count': response.get('meta', {}).get('skip_count', 0),
                'next_time': time.time() + response.get('track', {}).get('duration', 15) - 15,
            }

    def _get_skip_limit(self):
        """
        Return True if reached and False if didn't
        """
        sl = self._skip_limit
        if sl['method'] != 'on-demand':
            if sl['skip_count'] + 1 < sl['skip_limit']:
                logger.debug("Skip limit didn't reach, %r+1<%r",
                             sl['skip_count'], sl['skip_limit'])
                return False
        if sl['next_time'] < time.time():
            logger.debug("Skip limit didn't reach, %r<%r",
                         sl['next_time'], time.time())
            return False
        logger.debug("Finally, reached limit with  %r<%r",
                         sl['next_time'], time.time())
        logger.info("Seconds to allow next %r", sl['next_time'] - time.time())
        return True

    def _get_settings(self):
        time_stamp = time.time()
        if self._last_conn + REFRESH_MAX_RATE > time_stamp:
            return
        self._settings = self.__wahwah.request("GET", "/api/1.0/stations/%s/settings/" %
                                               (self.id))
        self._last_conn = time_stamp

    def _set_settings(self, id, value):
        self._last_conn = 0
        body = json.dumps({id: value})
        self._settings = self.__wahwah.request("POST", "/api/1.0/stations/%s/settings/" %
                              self.id, body=body)

    # Artist
    def _get_artist(self):
        if not self._artist_id:
            self._settings or self._get_settings()
            self._artist_id = self._settings['ARTIST']
        return self._artist_id

    artist = property(_get_artist)

    # Tempo
    def _get_tempo(self):
        self._get_settings()
        tempo = self._settings.get('tempo')
        if "0" == tempo:
            return "off"
        elif "33" == tempo:
            return "low"
        elif "66" == tempo:
            return "medium"
        elif "100" == tempo:
            return "high"
        else:
            return tempo

    def _set_tempo(self, tempo):
        if tempo not in ["off", "low", "medium", "high"]:
            return
        if tempo == "off":
            tempo = "0"
        elif tempo == "low":
            tempo = "33"
        elif tempo == "medium":
            tempo = "66"
        elif tempo == "high":
            tempo = "100"
        self._set_settings("tempo", tempo)

    tempo = property(_get_tempo, _set_tempo)

    # Discovery
    def _get_discovery(self):
        self._get_settings()
        return self._settings.get('discovery')

    def _set_discovery(self, discovery):
        if not discovery in ["off", "low", "medium", "high"]:
            return
        self._set_settings("discovery", discovery)

    discovery = property(_get_discovery, _set_discovery)

    # Popularity
    def _get_popularity(self):
        self._get_settings()
        return self._settings.get('popularity')

    def _set_popularity(self, popularity):
        if not popularity in ["off", "low", "medium", "high"]:
            return
        self._set_settings("popularity", popularity)

    popularity = property(_get_popularity, _set_popularity)

    # Similarity
    def _get_similarity(self):
        self._get_settings()
        return self._settings.get('similarity')

    def _set_similarity(self, similarity):
        if not similarity in ["off", "low", "medium", "high"]:
            return
        self._set_settings("similarity", similarity)

    similarity = property(_get_similarity, _set_similarity)