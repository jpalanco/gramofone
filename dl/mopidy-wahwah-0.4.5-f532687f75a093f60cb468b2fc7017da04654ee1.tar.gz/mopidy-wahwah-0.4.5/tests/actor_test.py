import unittest
import mock
from mopidy_wahwah import client, library, tracklist, playback, playlists, metadata
from mopidy.audio import DummyAudio
from mopidy_wahwah.actor import WahwahBackend


class TestActorCreation(unittest.TestCase):
    full_config = {
        'wahwah': {
            'auth_token': 'mytoken',
            'allow_unregistered': False,
        },
        'rpc': {
            'user': 'user',
            'password': 'password',
        },
    }


    @mock.patch('mopidy_wahwah.actor.WahwahClient', spec=client.WahwahClient)
    @mock.patch('mopidy_wahwah.actor.WahwahLibraryProvider', spec=library.WahwahLibraryProvider)
    @mock.patch('mopidy_wahwah.actor.WahwahTracklistProvider', spec=tracklist.WahwahTracklistProvider)
    @mock.patch('mopidy_wahwah.actor.WahwahPlaybackProvider', spec=playback.WahwahPlaybackProvider)
    @mock.patch('mopidy_wahwah.actor.WahwahPlaylistsProvider', spec=playlists.WahwahPlaylistsProvider)
    @mock.patch('mopidy_wahwah.actor.WahwahMetadataProvider', spec=metadata.WahwahMetadataProvider)
    def full_configuration_test(self, m_md, m_pl, m_pb, m_tl, m_lib, m_cli):
        self.m_audio = mock.MagicMock(spec=DummyAudio)
        cli_args = {'allow_unregistered': False,
                    'auth_token': 'mytoken',
                    'rpc_user': 'user',
                    'rpc_pass': 'password'}

        backend = WahwahBackend(self.full_config, self.m_audio)

        m_cli.assert_called_once_with(**cli_args)
        m_lib.assert_called_once_with(backend)
        m_tl.assert_called_once_with(backend)
        m_pb.assert_called_once_with(self.m_audio, backend)
        m_pl.assert_called_once_with(backend)
        m_md.assert_called_once_with(backend)

        self.assertIn('wahwah', backend.uri_schemes)
        self.assertEqual(backend.config, self.full_config)
