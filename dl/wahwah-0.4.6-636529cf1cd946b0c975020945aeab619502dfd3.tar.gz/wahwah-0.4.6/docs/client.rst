*****
Usage
*****

.. module:: wahwah.client
    :synopsis: The file containing the API


Connection Manager
==================

.. autoclass:: wahwah.client.WahwahConnection
    :members:


Client
======

.. autoclass:: wahwah.client.Client
    :members:
    :private-members:

Station
=======

.. autoclass:: wahwah.client.WahwahStation
    :members:
    :private-members:
