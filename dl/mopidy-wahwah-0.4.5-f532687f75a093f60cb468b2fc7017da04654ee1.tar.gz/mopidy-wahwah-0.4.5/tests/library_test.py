from __future__ import unicode_literals, absolute_import

import mock
import unittest

import pykka

from mopidy import core
from mopidy_wahwah import actor
from mopidy_wahwah.client import WahwahClient
from mopidy.models import Artist

class WahwahLibraryProviderOnlyTest(unittest.TestCase):
    full_config = {
        'wahwah': {
            'auth_token': 'mytoken',
            'allow_unregistered': False,
        },
        'rpc': {
            'user': 'user',
            'password': 'password',
        },
    }

    @mock.patch('mopidy_wahwah.actor.WahwahClient', spec=WahwahClient)
    def setUp(self, m_cli):
        self.m_cli = m_cli.return_value  # We want the instance, not the class!
        self.backend = actor.WahwahBackend.start(
            config=self.full_config, audio=None).proxy()
        self.core = core.Core(backends=[self.backend])
        self.library = self.core.library

    def tearDown(self):
        pykka.ActorRegistry.stop_all()

    def lookup_invalid_track_test(self):
        tracks = self.library.lookup('fake uri')
        self.assertEqual(tracks, [])

    def lookup_known_artist_test(self):
        self.m_cli.get_artist.return_value = ['slug', 'id', Artist(name='Slug', uri='wahwah:artist:slug')]
        tracks = self.library.lookup('wahwah:artist:slug')
        self.assertTrue(tracks)
        self.assertIn("wahwah:station:", tracks[0].uri)

    def lookup_known_station_test(self):
        self.m_cli.get_artist.return_value = ['slug', 'id', Artist(name='Slug', uri='wahwah:artist:slug')]
        tracks = self.library.lookup('wahwah:station:id')
        self.assertTrue(tracks)
        self.assertIn("wahwah:station:", tracks[0].uri)

    def lookup_unknown_artist_test(self):
        self.m_cli.get_artist.return_value = None
        tracks = self.library.lookup('wahwah:artist:slug')
        self.assertFalse(tracks)

    def lookup_unknown_station_test(self):
        self.m_cli.get_artist.return_value = None
        tracks = self.library.lookup('wahwah:station:id')
        self.assertFalse(tracks)


    def search_known_artist_test(self):
        self.m_cli.get_artist.return_value = ['slug', 'id', Artist(name='Slug', uri='wahwah:artist:slug')]
        self.m_cli.search_artist.return_value = []
        search_result = self.library.search(uri=['wahwah:artist:slug'])
        self.assertTrue(search_result[0].tracks)

    def search_known_station_test(self):
        self.m_cli.get_artist.return_value = ['slug', 'id', Artist(name='Slug', uri='wahwah:artist:slug')]
        self.m_cli.search_artist.return_value = []
        search_result = self.library.search(uri=['wahwah:station:slug'])
        self.assertTrue(search_result[0].tracks)

    def search_unknown_station_test(self):
        self.m_cli.get_artist.return_value = None
        self.m_cli.search_artist.return_value = []
        search_result = self.library.search(uri=['wahwah:station:slug'])
        self.assertFalse(search_result[0].tracks)