from __future__ import absolute_import, unicode_literals

import mock
import unittest

import pykka

from mopidy import core
from mopidy_wahwah import actor
from mopidy_wahwah.client import WahwahClient
from StringIO import StringIO
from ConfigParser import RawConfigParser

class WahwahMetadataOnlyTest(unittest.TestCase):
    full_config = {
        'wahwah': {
            'auth_token': 'mytoken',
            'allow_unregistered': False,
        },
        'rpc': {
            'user': 'user',
            'password': 'password',
        },
    }

    # Helper class, as specified mock helpers doc at the end:
    # http://www.voidspace.org.uk/python/mock/helpers.html#autospeccing
    class WahwahClientForTest(WahwahClient):
        _wahwah = None

    @mock.patch('mopidy_wahwah.actor.WahwahClient', spec=WahwahClientForTest)
    def setUp(self, m_cli):
        self.m_cli = m_cli.return_value  # We want the instance, not the class!
        self.backend = actor.WahwahBackend.start(
            config=self.full_config, audio=None).proxy()
        self.core = core.Core(backends=[self.backend])
        self.metadata = self.core.metadata

    def tearDown(self):
        pykka.ActorRegistry.stop_all()

    def get_user_token_true_test(self):
        self.m_cli._wahwah.auth_token = 'Auth-token'
        ret = self.metadata.get('wahwah:user', 'token')
        self.assertTrue(ret['token'])

    def get_user_token_false_test(self):
        self.m_cli._wahwah.auth_token = None
        ret = self.metadata.get('wahwah:user', 'token')
        self.assertFalse(ret['token'])

    def get_user_name_test(self):
        self.m_cli._wahwah.user_info = {'name': 'User'}
        ret = self.metadata.get('wahwah:user', 'name')
        self.assertEqual('User', ret['name'])
        
    def get_no_user_name_test(self):
        self.m_cli._wahwah.user_info = {'name': 'User'}
        ret = self.metadata.get('wahwah:user', 'name')
        self.assertEqual('User', ret['name'])

    def get_user_status_test(self):
        self.m_cli._wahwah.user_info = {'status': 'ANON'}
        ret = self.metadata.get('wahwah:user', 'status')
        self.assertEqual('ANON', ret['status'])

    def get_user_no_status_test(self):
        self.m_cli._wahwah.user_info = None
        ret = self.metadata.get('wahwah:user', 'status')
        self.assertEqual(None, ret['status'])

    @mock.patch('mopidy_wahwah.metadata.ConfigParser.RawConfigParser', spec=RawConfigParser)
    def config_test(self, m_config):
        m_conf_instance = m_config.return_value
        m_conf_instance.has_option.return_value = True
        m_conf_instance.get.return_value = 'My token'
        self.metadata.config('wahwah:service')
        self.m_cli.set_token.assert_called_once_with('My token')