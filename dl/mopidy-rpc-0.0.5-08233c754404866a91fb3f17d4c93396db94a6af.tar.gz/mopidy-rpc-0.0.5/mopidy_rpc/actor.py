from __future__ import unicode_literals

import logging
import os
try:
    import simplejson as json
except ImportError:
    import json
from httplib import HTTPException, HTTPConnection
from SocketServer import BaseRequestHandler,TCPServer

from . import rpc
import pykka
import threading
import time

from mopidy import models
from mopidy.core import CoreListener

from mopidy import core, models
from mopidy.utils import jsonrpc
import json

logger = logging.getLogger('mopidy.frontends.rpc')


class RPCFrontend(pykka.ThreadingActor, CoreListener):
    def __init__(self, config, core):
        super(RPCFrontend, self).__init__()
        self.config = config
        self._core = core
        self.server_thread = None
        self._setup_server()
        self.service_init = False
        self.end_of_track_flag = 0

    def _setup_server(self):
        try:
            self.crest_server = RPCTCPServer(( '',int(self.config['rpc']['port'])), rpc.RPCHandler)
            self.crest_server.set_core(self._core)
            self.service_init = True
            logger.info(u"RPC Service correctly loaded on port "+str(self.config['rpc']['port']))
        except Exception,e:
            logger.error(u"RPC Service not correctly loaded on port "+str(self.config['rpc']['port'])+u" ("+str(e)+u")")

    def _create_app(self):
        try:
            self.crest_server.serve_forever()
        except:
            pass

    def on_start(self):
        try:
            logger.debug('Starting RPC service')
            self.server_thread = threading.Thread(target=self._create_app).start()
            logger.info('RPC service running')
        except Exception,e:
            logger.error("RPC Service thread was not runnable ("+str(e)+")")

    def on_stop(self):
        logger.debug('Stopping RPC service')
        try:
            #self.crest_server.shutdown()
            self.crest_server.socket.shutdown(socket.SHUT_RDWR)
        except:
            pass
        try:
            self.crest_server.socket.close()
        except Exception,e:
            try:
                del fake_server
            except:
                logger.info("Some issues stopping RPC service (not critical, maybe frontend was not running)")
        logger.info('Stopped RPC service')

    def mute_changed(self, mute):
        if mute:
            logger.debug('RPC service sending MUTE')
            self.send_audiod_event("notify_mute")
        else:
            logger.debug('RPC service sending UNMUTE')
            self.send_audiod_event("notify_unmute")

    def track_playback_paused(self, tl_track, time_position):
        logger.debug('RPC service sending PAUSE')
        self.end_of_track_flag = 0
        self.send_audiod_event("notify_pause")

    def track_playback_resumed(self, tl_track, time_position):
        logger.debug('RPC service sending RESUME/PLAY')
        self.end_of_track_flag = 0
        self.send_audiod_event("notify_play")

    def track_playback_started(self, tl_track):
        logger.debug('RPC service sending PLAY')
        self.end_of_track_flag = 0
        self.send_audiod_event("notify_play")

    def track_playback_ended(self, tl_track, time_position):
        #logger.debug('RPC service sending STOP')
        #self.send_audiod_event("notify_stop")
        self.end_of_track_flag = self.end_of_track_flag + 1

    def playback_state_changed(self, old_state, new_state):
        state = str(new_state)
        if (state.find("stopped") >= 0) and (self.end_of_track_flag < 2):
            self.end_of_track_flag = 0
            logger.debug('RPC service sending STOP')
            self.send_audiod_event("notify_stop")


        logger.debug('RPC service statuschanged to '+new_state)

    def send_audiod_event(self,method):
        try:
            get_id_str = {"jsonrpc": "2.0",
                          "id": 1,
                          "method": "call",
                          "params": [
                              "session",
                              "login",
                              {
                                  "username": self.config['rpc']['user'],
                                  "password": self.config['rpc']['password']
                              }
                          ]
                          }

            put_event_str = {"jsonrpc": "2.0",
                             "id": 1,
                             "method": "call",
                             "params": ["audiod",method, {}]
                             }

            connection = HTTPConnection("localhost", timeout=5)
            connection.request("POST",
                               "/api/00000000000000000000000000000000",
                               body=json.dumps(get_id_str))
            sid = json.loads(connection.getresponse().read())
            logger.debug("Localhost Login RPC response '%s'", repr(sid))
            connection.request("POST", "/api/%s" % sid['result'][1]['sid'],
                               body=json.dumps(put_event_str))
            sid = json.loads(connection.getresponse().read())
            logger.debug("Localhost Audiod RPC response '%s'", repr(sid))
        except Exception as e:
            logger.error("Notifying localhost failed '%s'", repr(e))


class RootResource(object):
    pass


class MopidyResource(object):
    pass

class RPCTCPServer(TCPServer):

    def __init__(self, server_address, RequestHandlerClass):
        #self.allow_reuse_address = True
        TCPServer.__init__(self, server_address, RequestHandlerClass)

    def set_core(self,proxycore):
        inspector = jsonrpc.JsonRpcInspector(
            objects={
                'core.get_uri_schemes': core.Core.get_uri_schemes,
                'core.library': core.LibraryController,
                'core.playback': core.PlaybackController,
                'core.playlists': core.PlaylistsController,
                'core.tracklist': core.TracklistController,
                'core.metadata': core.MetadataController,
            })
        self.jsonrpc = jsonrpc.JsonRpcWrapper(
            objects={
                'core.describe': inspector.describe,
                'core.get_uri_schemes': proxycore.get_uri_schemes,
                'core.library': proxycore.library,
                'core.playback': proxycore.playback,
                'core.playlists': proxycore.playlists,
                'core.tracklist': proxycore.tracklist,
                'core.metadata': proxycore.metadata,
            },
            decoders=[models.model_json_decoder],
            encoders=[models.ModelJSONEncoder])
