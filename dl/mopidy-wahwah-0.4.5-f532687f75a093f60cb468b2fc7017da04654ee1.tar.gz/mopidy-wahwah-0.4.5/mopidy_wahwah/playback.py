from __future__ import unicode_literals, absolute_import

import logging

from mopidy.backends.base import BasePlaybackProvider
from mopidy.frontends.mpd.exceptions import MpdPermissionError


logger = logging.getLogger("mopidy.backends.wahwah")

MIN_CHANGE_RATE = 5


class WahwahPlaybackProvider(BasePlaybackProvider):
    def set_had_error(self, value):
        logger.debug("Had error set to %r", value)
        self.__had_error = value

    def get_had_error(self):
        logger.debug("Had error being retrieved with value %r", self.__had_error)
        return self.__had_error

    had_error = property(get_had_error, set_had_error)

    def __init__(self, *args, **kwargs):
        super(WahwahPlaybackProvider, self).__init__(*args, **kwargs)
        self.__had_error = 0
        self.skip_raise = False
        self.last_duration = 0

    def play(self, track):
        logger.debug("play(%r)", track)
        provider, element_type, data = track.uri.split(':', 2)
        assert "wahwah" == provider, "Uri " + track.uri + " is not wahwah"
        assert element_type == "station", \
            "The provided track is not an station"
        self.station = track
        if self.backend.wahwah.check_limit(data) and not self.skip_raise:
            logger.debug("check_limit == True!")
            ex = MpdPermissionError(index=0, command='next')
            ex.message = "Skip limit reached"
            raise ex
        self.skip_raise = False
        self.update_duration(from_play=True)
        try:
            track = self.backend.wahwah.track_provider(data,
                                                       self.last_duration,
                                                       bool(self.had_error))
        except Exception as e:
            logger.exception("Got an exception while gathering track, ignoring it %r", e)
            track = False
        if track:
            logger.debug("Playing given track %r", track)
            self.track = track
            ret = super(WahwahPlaybackProvider, self).play(track)
        else:
            logger.debug("Playing is not posible for given track")
            ret = False
        if ret:
            self.had_error = 0
        return ret

    def pause(self):
        logger.debug("pause()")
        return BasePlaybackProvider.pause(self)

    def seek(self, time_position):
        logger.debug("seek()")
        return False

    def resume(self):
        logger.debug("resume()")
        return BasePlaybackProvider.resume(self)

    def on_playback_error(self, error, debug):
        logger.warning("ON PLAYBACK ERROR CALLED for: %r", error)
        logger.debug("Debug message: %r", debug)

        if 'Resource not found.' in error and 'gst_soup_http_src_finished_cb' in debug:
            return False

        self.backend.wahwah.status_code = 506
        self.had_error += 1
        if self.had_error > 3:
            logger.warning('Too many errors, not retrying, just logging now.')
            return False
        if "gst_soup_http_src_parse_status" in debug:
            return True
        if "Buffering Error on Gstreamer::Playbin2" in error:
            return True
        return False

    def update_duration(self, from_play=False):
        duration = int(self.get_time_position()/1000)
        if from_play and duration == 0:
            logger.info("Reported duration will be %r", self.last_duration)
            return

        logger.info("Reported duration will be %r", duration)
        self.last_duration = duration