from __future__ import unicode_literals

import unittest
import os
import collections

from wahwah.client import Client
from unittest import skipUnless, skip
try:
    import facebook
except ImportError:
    facebook = None


__all__ = ['setUpModule', 'WahwahLoggedClientTest', 'WahwahUnloggedClientTest']

@skipUnless('WAHWAH_SERVER' in os.environ, "WAHWAH_SERVER to use should be specified")
def setUpModule():
    global artist_name, failure_artist_name
    artist_name = 'Alesana'


# This will be executed through subclassing!
class WahwahClientTest(object):
    def setUp(self):
        self.longMessage = True

    def test_client_search_artist(self):
        artists = self.client.search_artist(artist_name)
        self.assertTrue(issubclass(type(artists), collections.Iterable), msg='Artist should be iterable')
        self.assertIsNotNone(artists)
        artist = artists[0]
        self.assertIn('id', artist, msg='Search result should contain "id" parameter in each response in the array')
        self.assertIn('artist', artist, msg='Search result should have "name" parameter in each response in the array')
        self.assertIn('slug', artist, msg='Search result should contain "slug" parameter in each response in the array')

    def test_create_station(self):
        artists = self.client.search_artist(artist_name)
        id_ = artists[0]['id']
        sta = self.client.get_station(id_)
        self.assertIsNotNone(sta)
        self.assertEqual(sta.artist, id_)

        sta_art = self.client.get_station(artist_id=id_)
        self.assertIsNotNone(sta_art)
        self.assertEqual(sta_art.artist, id_)

        sta_sta = self.client.get_station(station_id=sta.id)
        self.assertIsNotNone(sta_sta)
        self.assertEqual(sta_art.artist, id_)
        self.assertEqual(sta_art.id, sta.id)


# This will be executed through subclassing
class WahwahStationTest(object):
    def setUp(self):
        pass

    def test_artist(self):
        artists = self.client.search_artist(artist_name)
        station = self.client.get_station(artists[0]['id'])

        self.assertEqual(station.artist, artists[0]['id'])

    def test_tempo(self):
        artists = self.client.search_artist(artist_name)
        station = self.client.get_station(artists[0]['id'])

        station.tempo = 'off'
        self.assertEqual(station.tempo, 'off')

        station.tempo = 'low'
        self.assertEqual(station.tempo, 'low')

        station.tempo = 'medium'
        self.assertEqual(station.tempo, 'medium')

        station.tempo = 'high'
        self.assertEqual(station.tempo, 'high')

        station.tempo = None
        self.assertEqual(station.tempo, 'high')

    def test_discovery(self):
        artists = self.client.search_artist(artist_name)
        station = self.client.get_station(artists[0]['id'])

        station.discovery = 'off'
        self.assertEqual(station.discovery, 'off')

        station.discovery = 'low'
        self.assertEqual(station.discovery, 'low')

        station.discovery = 'medium'
        self.assertEqual(station.discovery, 'medium')

        station.discovery = 'high'
        self.assertEqual(station.discovery, 'high')

        station.discovery = None
        self.assertEqual(station.discovery, 'high')

    def test_similarity(self):
        artists = self.client.search_artist(artist_name)
        station = self.client.get_station(artists[0]['id'])

        station.similarity = 'off'
        self.assertEqual(station.similarity, 'off')

        station.similarity = 'low'
        self.assertEqual(station.similarity, 'low')

        station.similarity = 'medium'
        self.assertEqual(station.similarity, 'medium')

        station.similarity = 'high'
        self.assertEqual(station.similarity, 'high')

        station.similarity = None
        self.assertEqual(station.similarity, 'high')

    def test_popularity(self):
        artists = self.client.search_artist(artist_name)
        station = self.client.get_station(artists[0]['id'])

        station.popularity = 'off'
        self.assertEqual(station.popularity, 'off')

        station.popularity = 'low'
        self.assertEqual(station.popularity, 'low')

        station.popularity = 'medium'
        self.assertEqual(station.popularity, 'medium')

        station.popularity = 'high'
        self.assertEqual(station.popularity, 'high')

        station.popularity = None
        self.assertEqual(station.popularity, 'high')


# Need to subclass unittest.TestCase because avoided it in base class
class WahwahUnloggedClientTest(unittest.TestCase, WahwahClientTest, WahwahStationTest):
    def setUp(self):
        self.client, self.client2 = [Client(allow_unregistered=True,
                        server=os.environ['WAHWAH_SERVER']) for _ in xrange(2)]
        self.client = Client(server=os.environ['WAHWAH_SERVER'], allow_unregistered=True)
        WahwahClientTest.setUp(self)
        WahwahStationTest.setUp(self)

    def test_login_without_token(self):

        # First check client integrity
        self.assertIsNotNone(self.client)

        self.client.re_set_client()

        # Check login process went correctly
        self.assertFalse(self.client.auth_token, msg='On anonymous login, no auth_token should be returned')
        self.assertIsNotNone(self.client.login_info, msg="There isn't login info being returned")

        # Check user relevant information
        self.assertFalse(self.client.user_id, msg='User id should be empty')
        self.assertIn('name', self.client.user_info, msg='Name should be in /account/ request')
        self.assertIn('status', self.client.user_info, msg='Client status should be returned for non logged in user')
        self.assertEqual(self.client.user_info['name'], 'Anonymous', msg='Anonymous should be the name of a non-logged in user')
        self.assertEqual(self.client.user_info['status'], 'ANON', msg='The status of an anonymous user should be ANON')

    @skip('Unlogged client should not support such thing')
    def test_similarity(self):
        WahwahStationTest.test_similarity(self)

    @skip('Unlogged client should not support such thing')
    def test_popularity(self):
        WahwahStationTest.test_popularity(self)

    @skip('Unlogged client should not support such thing')
    def test_discovery(self):
        WahwahStationTest.test_discovery(self)

    @skip('Unlogged client should not support such thing')
    def test_tempo(self):
        WahwahStationTest.test_tempo(self)



# Need to subclass unittest.TestCase because avoided it in base class
class WahwahLoggedClientTest(unittest.TestCase, WahwahClientTest, WahwahStationTest):
    @classmethod
    def setUpClass(cls):
        cls.user = {}
        if 'FACEBOOK_TOKEN' in os.environ:
            cls.user['token'] = os.environ.get('FACEBOOK_TOKEN', None)
            cls.user['name'] = os.environ.get('FACEBOOK_NAME', None)
            cls.user['id'] = os.environ.get('FACEBOOK_ID', None)
        elif not (set(['FACEBOOK_APP_ID', 'FACEBOOK_APP_SECRET']) <= set(os.environ)):
            raise unittest.SkipTest('FACEBOOK_APP_ID and FACEBOOK_APP_SECRET should be set')
        elif not facebook:
            raise unittest.SkipTest('facebook python package should be installed for this tests')
        else:
            cls.app = dict()
            cls.app['id'] = os.environ['FACEBOOK_APP_ID']
            cls.app['secret'] = os.environ['FACEBOOK_APP_SECRET']
            cls.user['name'] = 'Test user'
            graph = facebook.GraphAPI()
            # We first get the facebook app_access_token
            app_access_token = facebook.get_app_access_token(
                                            cls.app['id'],
                                            cls.app['secret'])
            graph.access_token = app_access_token

            # Then we create the user
            user = graph.request(cls.app['id'] + "/accounts/test-users",
                                           args={"installed": True,
                                                 "name": cls.user['name'],
                                                 "method": "post"})

            cls.user['token'] = user['access_token']
            cls.user['id'] = user['id']

    @classmethod
    def tearDownClass(cls):
        graph = facebook.GraphAPI(access_token=cls.user['token'])
        graph.request(cls.user['id'], args={"method": "delete"})


    def setUp(self):
        self.client, self.client2 = [
                        Client(auth_token=self.user['token'],
                        server=os.environ['WAHWAH_SERVER']) for _ in xrange(2)]
        WahwahClientTest.setUp(self)
        WahwahStationTest.setUp(self)

    def test_login_with_token(self):
        # First check client integrity
        self.assertIsNotNone(self.client)

        self.client.re_set_client()

        # Check login process went correctly
        self.assertTrue(self.client.auth_token, msg='Auth token not updated in client object')
        self.assertIsNotNone(self.client.login_info)
        self.assertIn('access_token', self.client.login_info,
                      msg='Regression of bug #3. Not new token returned')

        # Check user relevant information
        self.assertTrue(self.client.user_id, msg='User id for logged in token should exist')
        if 'FACEBOOK_NAME' in os.environ:
            self.assertEqual(self.client.user_info['name'], os.environ['FACEBOOK_NAME'],
                             msg='Real name should be returned in name parameter')
        self.assertEqual(self.client.user_info['status'], 'REG')

    def test_user_favorites(self):
        artists = self.client.search_artist(artist_name)
        sta = self.client.get_station(artists[0]['id'])
        self.client.user_favorites.add(sta)
        self.assertIn(sta, self.client2.user_favorites)

        self.client.user_favorites.discard(sta)
        self.assertNotIn(sta, self.client.user_favorites)

    def test_user_stations(self):
        artists = self.client.search_artist(artist_name)
        sta = self.client.get_station(artists[0]['id'])
        sta.get_track()
        self.assertIn(sta, self.client.user_stations)

        self.client.user_stations.discard(sta)
        self.assertNotIn(sta, self.client.user_stations)

