from __future__ import unicode_literals, absolute_import

import re
from setuptools import setup, find_packages


def get_version(filename):
    content = open(filename).read()
    metadata = dict(re.findall("__([a-z]+)__ = '([^']+)'", content))
    return metadata['version']


setup(
    name='wahwah',
    version=get_version('wahwah/__init__.py'),
    url='https://github.com/fonlabs/wahwah',
    license='MIT',
    author='Javier Domingo Cansino',
    author_email='javier.domingo@fon.com',
    description='Lightweight wahwah binding for Python',
    long_description=open('README').read(),
    packages=find_packages(),
    include_package_data=True,
    entry_points={}
)
