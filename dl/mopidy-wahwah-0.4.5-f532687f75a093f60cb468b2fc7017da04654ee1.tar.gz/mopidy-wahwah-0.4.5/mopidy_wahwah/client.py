from __future__ import unicode_literals, absolute_import
from contextlib import contextmanager
from time import time

try:
    import simplejson as json
except ImportError:
    import json
import logging
from httplib import HTTPConnection
from weakref import WeakKeyDictionary
import pykka

from wahwah import Client
from wahwah.exceptions import WahwahNotConnected, WahwahException, \
    WahwahNotLogged, WahwahStatusError, WahwahTimeout
from mopidy.models import Playlist, Artist, Track, Album
from mopidy.frontends.mpd.exceptions import MpdAckError

logger = logging.getLogger("mopidy.backends.wahwah")


from mopidy.frontends.mpd import session


def send_idle(subsystem):
    listeners = pykka.ActorRegistry.get_by_class(session.MpdSession)
    for listener in listeners:
        getattr(listener.proxy(), 'on_idle')(subsystem)

class MpdConnectionError(MpdAckError):
    error_code = MpdAckError.ACK_ERROR_SYSTEM

    def __init__(self, *args, **kwargs):
        super(MpdConnectionError, self).__init__(*args, **kwargs)

        if len(args) > 0:
            self.message = "Exception: " + str(type(args[0]).__name__)
        else:
            self.message = 'Connection Error'
        # self.command = ''


class MpdUnregisteredServiceError(MpdAckError):
    error_code = MpdAckError.ACK_ERROR_SYSTEM

    def __init__(self, *args, **kwargs):
        super(MpdUnregisteredServiceError, self).__init__(*args, **kwargs)
        self.message = 'Unregistered Service'


class WahwahClient(object):
    def __init__(self, auth_token=None,
                 allow_unregistered=False,
                 rpc_user='admin',
                 rpc_pass='admin',
                 backend_uri=None,
                 backend_id=None):
        self._status = 'undefined' or 'success' or 'unregistered' or 'login' or 'error'
        logger.debug('Going to use %r backend with %r id', backend_uri, backend_id)
        self.status_code = 200
        self.last_error = (None, None)
        self.__artist_id_slug = WeakKeyDictionary()
        self.__artist_station = WeakKeyDictionary()  # We reset the artist-queue backlog

        self._wahwah = Client(auth_token, allow_unregistered=allow_unregistered,
                              backend_id=backend_id, backend_uri=backend_uri)
        self.set_token(auth_token)

    def set_status(self, value):
        logger.debug("Changing status from %r to %r", self._status, value)
        if self._status != value:
            send_idle('database')
        self._status = value

    def get_status(self):
        return self._status
    status = property(get_status, set_status)

    def get_appid(self):
        return self._wahwah.backend_id
    appid = property(get_appid)

    def set_token(self, token):
        send_idle('database')
        self.__artist_station = WeakKeyDictionary()  # We reset the artist-queue backlog
        old_id = self._wahwah.user_id
        self._wahwah.auth_token = token  # Set the token in the client
        with self.wahwah_flows(raises=False):
            self._wahwah.re_set_client()  # We instruct it to
            if old_id != self._wahwah.user_id:
                self.__notify_logon()

    def __notify_logon(self):
        try:
            get_id_str = {"jsonrpc": "2.0",
                          "id": 1,
                          "method": "call",
                          "params": [
                              "session",
                              "login",
                              {
                                  "username": "audio",
                                  "password": "Pr7xmf07UyTpCWvq8nXg"
                              }
                          ]
                          }

            put_token_str = {"jsonrpc": "2.0",
                             "id": 1,
                             "method": "call",
                             "params": [
                                 "audiod",
                                 "set_auth_token",
                                 {
                                     "section": "wahwah",
                                     "auth_token": self._wahwah.auth_token
                                 }
                             ]
                             }
            connection = HTTPConnection("localhost", timeout=5)
            connection.request("POST",
                               "/api/00000000000000000000000000000000",
                               body=json.dumps(get_id_str))
            sid = json.loads(connection.getresponse().read())
            logger.debug("Localhost RPC response '%s'", repr(sid))
            connection.request("POST", "/api/%s" % sid['result'][1]['sid'],
                               body=json.dumps(put_token_str))
            sid = json.loads(connection.getresponse().read())
        except Exception as e:
            logger.exception("Notifying localhost failed '%r'", e)


    def __parse_stations(self, stations):
        tracks = list()
        with self.wahwah_flows():
            for station in stations:
                try:
                    artist_objs = list()
                    for artist in station._data['meta']['artists']:
                        artist_args = dict()
                        artist_args['name'] = artist['name']
                        artist_args['uri'] = "wahwah:artist:" + artist['slug']
                        artist_obj = Artist(**artist_args)
                        self.__artist_id_slug[artist_obj] = (artist['slug'], artist['id'])
                        logger.debug("Adding ('%s','%s','%s')" % (artist['slug'],
                                     artist['id'], repr(artist_obj)))
                        artist_objs.append(artist_obj)
                    artist_t = self.get_artist(
                        slug=station._data['meta']['artists'][0]['slug'])
                except Exception as e:
                    logger.error("Skipping station %r because of an error while parsing stations: %r",
                                 station._data['slug'], e)
                    continue
                if not artist_t:
                    continue
                tracks.append(Track(uri="wahwah:station:" + artist_t[1],
                                    artists=[artist_t[2]],
                                    name=station._data['name']))

        return tracks

    def check_available(self):
        logger.debug("Checking availability")
        try:
            self._wahwah._check_status(connection_too=True)
        except WahwahNotLogged:
            self.status = 'unregistered'
            self.status_code = 501
            self.last_error = (501, time())
            logger.error('Client is not logged into wahwah, rising error')
            return False
        except WahwahTimeout as e:
            self.status = 'error'
            self.status_code = 505
            self.last_error = (505, time())
            logger.error('No internet connection to Wahwah. %r', e)
            return False
        except WahwahNotConnected as e:
            self.status = 'error'
            self.status_code = 502
            self.last_error = (502, time())
            logger.error('No internet connection to Wahwah. %r', e)
            return False
        except WahwahException as e:
            self.status = 'error'
            self.status_code = 503
            self.last_error = (503, time())
            logger.error('Some exception in wahwah connection. %r', e)
            return False
        except Exception as e:
            self.status = 'error'
            self.status_code = 504
            self.last_error = (504, time())
            logger.error('Some exception in wahwah client. %r', e)
            return False
        else:
            self.status = 'success'
            self.status_code = 200
            logger.debug("Connection available")
            return True

    def search_artist(self, keywords):
        logger.debug('search_artist()')
        with self.wahwah_flows():
            artists = self._wahwah.search_artist(keywords)

        artist_objs = list()
        for artist in artists:
            artist_args = dict()
            artist_args['name'] = artist['artist']
            artist_args['uri'] = "wahwah:artist:" + artist['slug']
            artist_obj = Artist(**artist_args)
            self.__artist_id_slug[artist_obj] = (artist['slug'], artist['id'])
            logger.debug("Adding ('%s','%s','%s')" % (artist['slug'],
                         artist['id'], repr(artist_obj)))
            artist_objs.append(artist_obj)
        return artist_objs

    def get_artist(self, id=None, slug=None, recursion=False):
        logger.debug('get_artist()')
        if (not slug) and (not id):
            return None
        for a, (s, i) in self.__artist_id_slug.iteritems():
            if slug == s:
                return (s, i, a)
            if id == i:
                return (s, i, a)
        if recursion:
            return None
        if slug:
            # This is to maintain the reference to the object
            artists = self.search_artist(slug)  # noqa
            return self.get_artist(slug=slug, recursion=True)
        if id:
            with self.wahwah_flows(self):
                try:
                    sta = self._wahwah.get_station(id)
                except WahwahStatusError as e:
                    if e.status == 404:
                        logger.warning("Such id '%r' doesn't exist in theory", id)
                    logger.warning("Got %r status when gathering id", e.status)
                    sta = None
            if not sta:
                logger.debug("Such station id doesn't exist (%r)", id)
                return None
            artist_objs = list()
            for artist in sta._data.get('meta', {}).get('artists'):
                artist_args = dict()
                artist_args['name'] = artist['name']
                artist_args['uri'] = 'wahwah:artist:' + artist['slug']
                artist_obj = Artist(**artist_args)
                self.__artist_id_slug[artist_obj] = (artist['slug'], artist['id'])
                logger.debug("Adding by station ('%s','%s','%s')" % (artist['slug'],
                             artist['id'], repr(artist_obj)))
                artist_objs.append(artist_obj)
            slug = sta._data.get('artist_slug',
                                 sta._data.get('meta', {}).get('artists', [{}])[0].get('slug',
                                               sta._data.get('slug').rsplit('-radio-', 1)[0]))
            art = self.get_artist(slug=slug)
            if art:
                logger.debug("Adding station to cache %r -> %r", art[2], sta)
                self.__artist_station[art[2]] = sta
                return art
            else:
                logger.error("Somehow, we have artist id %r but no artist: %r", id, art)
                return None
        return None

    def get_station(self, artist=None, id=None):
        logger.debug("get_station()")
        if artist:
            s, i = self.__artist_id_slug[artist]
            a = (s, i, artist)
        elif id:
            a = self.get_artist(id=id)
        else:
            logger.error("Something going wrong, not id nor artist!")

        with self.wahwah_flows():
            sta = self._wahwah.get_station(a[1])
            self.__artist_station[a[2]] = sta
            logger.debug('stored_playlist from get_station()')
            send_idle('stored_playlist')
        return sta

    def check_limit(self, id):
        logger.debug("check_limit()")
        art = self.get_artist(id=id)
        artist = art[2]
        if artist in self.__artist_station:
            sta = self.__artist_station[artist]
        else:
            try:
                sta = self.get_station(artist)
            except:
                logger.debug('check_limit exception on get_station')
            finally:
                return False
        try:
            return sta._get_skip_limit()  #
        except Exception as e:
            logger.exception("Checking limit raised, so False %r", e)
            return False

    def track_provider(self, id, duration, had_error=False):
        logger.debug("track_provider()")
        t = None
        track = None
        art = self.get_artist(id=id)
        artist = art[2]
        if not artist in self.__artist_station:
            sta = self.get_station(artist)
        else:
            sta = self.__artist_station[artist]
        with self.wahwah_flows():
            self._wahwah._check_status()
            t = sta.get_track(had_error=had_error, duration=duration)

        if not t:
            self.status = 'error'
            self.status_code = sta
            self.last_error = (505, time())
            logger.error('No track available for this artist')
        else:
            track_args = dict()
            track_args['name'] = t['title']
            track_args['uri'] = t['uri']
            if t['art_name'] != artist.name:
                art = self.get_artist(slug=t['art_slug'], recursion=True)
                if art:
                    artist = art[2]
                else:
                    artist = Artist(
                        uri="wahwah:artist:" + t['art_slug'],
                        name=t['art_name'],)
            track_args['artists'] = [artist]
            track_args['album'] = Album(
                name=t['alb_name'],
                artists=[artist],
                )
            track_args['length'] = int(t['length']) * 1000
            track = Track(**track_args)

        logger.debug("Track provider returning track: %r", track)
        return track

    def get_user_favorites(self):
        stations = self._wahwah.user_favorites
        stations = self.__parse_stations(stations)
        return Playlist(uri="wahwah:user:favorites",
                        name="Favorites by Wahwah",
                        tracks=stations)

    def get_user_stations(self):
        stations = self._wahwah.user_stations
        stations = self.__parse_stations(stations)
        return Playlist(uri="wahwah:user:stations",
                        name="Stations by Wahwah",
                        tracks=stations)

    def update_favorites(self, stations):
        with self.wahwah_flows():
            logger.debug("Updating favorites to '%s'" % repr(stations))
            for new_favorite in stations.tracks:
                if new_favorite.name not in\
                        [station._data['name'] for station in
                         self._wahwah.user_favorites]:
                    logger.debug("Track not in favorites, lets add it!: %s",
                                 new_favorite)
                    if "wahwah:station:" not in new_favorite.uri:
                        logger.warning("It is not permitted to add non-wahwah " +
                                       "tracks to favorites")
                        continue
                    artist = next(iter(new_favorite.artists))
                    station = self.get_station(artist)
                    if station:
                        self._wahwah.user_favorites.add(station)

            for real_fav in self.get_user_favorites().tracks:
                if real_fav not in stations.tracks:
                    logger.debug("Favorite not in tracks, lets del it!: %s",
                                 real_fav)
                    artist = next(iter(real_fav.artists))
                    station = self.get_station(artist)
                    if station:
                        self._wahwah.user_favorites.discard(station)

    def update_stations(self, stations):
        with self.wahwah_flows():
            for new_station in stations.tracks:
                if new_station.name not in [station._data['name'] for station in
                                            self._wahwah.user_stations]:
                    logger.debug("Track not in stations, lets add it!: %s",
                                 new_station)
                    if "wahwah:station:" not in new_station.uri:
                        logger.warning("It is not permitted to add non-wahwah " +
                                       "tracks to favorites")
                        continue
                    artist = next(iter(new_station.artists))
                    station = self.get_station(artist)
                    if station:
                        self._wahwah.user_stations.add(station)

            for real_sta in self.get_user_stations().tracks:
                if real_sta not in stations.tracks:
                    logger.debug("Station not in tracks, lets add it!: %s",
                                 real_sta)
                    artist = next(iter(real_sta.artists))
                    station = self.get_station(artist)
                    if station:
                        self._wahwah.user_stations.discard(station)

    @contextmanager
    def wahwah_flows(self, raises=True):
        try:
            yield
        except WahwahNotLogged as e:
            self.status = 'unregistered'
            self.status_code = 501
            self.last_error = (501, time())
            logger.error('Client is not logged into wahwah, rising error')
            if raises:
                raise MpdUnregisteredServiceError()
        except WahwahTimeout as e:
            self.status = 'error'
            self.status_code = 505
            self.last_error = (505, time())
            logger.error('Timeout in connection to Wahwah. %r', e)
            if raises:
                raise MpdConnectionError()
        except WahwahNotConnected as e:
            self.status = 'error'
            self.status_code = 502
            self.last_error = (502, time())
            logger.error('No internet connection to Wahwah. %r', e)
            if raises:
                raise MpdConnectionError()
        except WahwahException as e:
            self.status = 'error'
            self.status_code = 503
            self.last_error = (503, time())
            logger.exception('Some exception in wahwah connection. %r', e)
            if raises:
                raise MpdConnectionError()
        except Exception as e:
            self.status = 'error'
            self.status_code = 504
            self.last_error = (504, time())
            logger.exception('Some exception in wahwah client. %r', e)
            if raises:
                raise MpdConnectionError()
        else:
            self.status = 'success'
            self.status_code = 200