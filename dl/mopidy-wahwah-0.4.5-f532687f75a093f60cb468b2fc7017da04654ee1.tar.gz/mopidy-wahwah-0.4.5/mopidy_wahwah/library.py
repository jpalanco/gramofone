from __future__ import unicode_literals, absolute_import

import logging

from mopidy.backends.base import BaseLibraryProvider
from mopidy.models import SearchResult, Track


logger = logging.getLogger("mopidy.backends.wahwah")


class WahwahLibraryProvider(BaseLibraryProvider):
    def lookup(self, uri):
        """
        Looks up for the given uri. It should only return station tracks.
        Can raise various Mpd errors depending on the state of the wahwah client.

        It will analyze two types of uris, the ones starting with
        `wahwah:artist:` and the ones starting with `wahwah:stations:`.
        """
        logger.debug("Looking up uri: " + uri)
        provider, element_type, data = uri.split(":", 2)
        assert "wahwah" == provider, "Uri " + uri + " is not wahwah"
        if element_type == "artist":
            artist_t = self.backend.wahwah.get_artist(slug=data)
            if not artist_t:
                logger.warning("The slug was invented! Use search!=> " +
                               repr(artist_t))
                return []
            uri = "wahwah:station:" + artist_t[1]
            element_type = "station"
            logger.debug("Uri 'wahwah:artist:%s' converted to '%s'" %
                         (artist_t[0], uri))
            track = Track(uri=uri, artists=[artist_t[2]],
                          name=artist_t[2].name + " Radio")
            return [track]
        elif element_type == "station":
            artist_t = self.backend.wahwah.get_artist(id=data)
            if not artist_t:
                logger.error("The id was invented! Use search!=> " +
                             repr(artist_t))
                return []
            if data == artist_t[0]:
                logger.warning("The given id is not the id!"
                               " It is the slug!!!")
            uri = "wahwah:station:" + artist_t[1]
            track = Track(uri=uri, artists=[artist_t[2]],
                          name=artist_t[2].name + " Radio")

            logger.debug("Returning track %s" % (repr(track.__dict__)))
            return [track]
        return []

    def search(self, query=None, uris=None):
        logger.debug("Searching for " + repr(query) +
                     " with scope " + repr(uris))
        track_results = list()
        artist_results = list()
        if query is None:
            query = dict()
        for (field, values) in query.iteritems():
            for value in values:
                q = value.strip()
                if field == 'uri' and "wahwah:" in value:
                    track_results += self.lookup(q)
                else:
                    artist_results.extend(self.backend.wahwah.search_artist(q))
        logger.debug("For '%s' returning tracks => '%s' and artists => '%s'" %
                    (repr(query), repr(track_results), repr(artist_results)))
        return SearchResult(uri='wahwah:search',
                            tracks=track_results, artists=artist_results)

    def find_exact(self, query=None, uris=None):
        result = self.search(query, uris)
#        for artist in result.artists:
#            if uris:
#                artist.uri,
        return result
