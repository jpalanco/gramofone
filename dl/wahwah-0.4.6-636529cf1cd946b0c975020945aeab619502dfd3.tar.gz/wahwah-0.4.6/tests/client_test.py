from __future__ import unicode_literals

import unittest
import mock

from wahwah.client import Client
from wahwah.connection import WahwahConnection
from wahwah.station import WahwahStation
from wahwah.list import WahwahUserList
from wahwah import WAHWAH_SERVER
from wahwah.exceptions import WahwahException
from mock import MagicMock
from threading import Thread



class TestClient(unittest.TestCase):

    @mock.patch('wahwah.client.Thread',
                spec=Thread)
    @mock.patch('wahwah.client.WahwahUserList',
                spec=WahwahUserList)
    @mock.patch('wahwah.client.WahwahStation',
                spec=WahwahStation)
    @mock.patch('wahwah.client.WahwahConnection',
                spec=WahwahConnection)
    def setUp(self, mc_con, mc_sta, mc_list, mc_thread):
        self.mc_con = mc_con
        self.mc_sta = mc_sta
        self.mc_list = mc_list
        self.mc_thread = mc_thread
        self.mo_con = mc_con.return_value
        self.mo_sta = mc_sta.return_value
        self.mo_list = mc_list.return_value
        self.mo_thread = mc_thread.return_value

        self.empty_cli = Client()
        self.filled_cli = Client(auth_token='My-token', server='beta',
                     allow_unregistered=True)


    @mock.patch('wahwah.client.Thread',
                spec=Thread)
    @mock.patch('wahwah.client.WahwahUserList',
                spec=WahwahUserList)
    @mock.patch('wahwah.client.WahwahStation',
                spec=WahwahStation)
    @mock.patch('wahwah.client.WahwahConnection',
                spec=WahwahConnection)
    def client_creation_empty_test(self, mc_con, mc_sta, mc_list, mc_thread):
        mo_con = mc_con.return_value
        mo_list = mc_list.return_value

        cli = Client()
        # Check empty properties
        self.assertIsNone(cli.auth_token)
        self.assertIsNone(cli.login_info)
        self.assertIsNone(cli.user_info)
        self.assertIsNone(cli.user_id)
        # Check not empty properties
        self.assertIsNotNone(cli.server)
        self.assertIsNotNone(cli.allow_unregistered)
        self.assertIsNotNone(cli.user_favorites)
        self.assertIsNotNone(cli.user_stations)
        self.assertIsNotNone(cli.wahwah)
        # Check connection
        mc_con.assert_called_once_with(WAHWAH_SERVER['prod']['server'],
                                       timeout=7)
        self.assertEqual(cli.wahwah, mo_con)
        mo_con.reset.assert_called_once_with()
        # Check server
        self.assertIsInstance(cli.server, basestring)
        self.assertEqual(cli.server, 'prod')
        # Check registered
        self.assertIsInstance(cli.allow_unregistered, bool)
        self.assertFalse(cli.allow_unregistered)
        # Check lists
        mc_list.assert_any_call(cli, 'favorites')
        mc_list.assert_any_call(cli, 'stations')
        self.assertEqual(mo_list, cli.user_favorites)
        self.assertEqual(mo_list, cli.user_stations)


    @mock.patch('wahwah.client.WahwahUserList',
                spec=WahwahUserList)
    @mock.patch('wahwah.client.WahwahStation',
                spec=WahwahStation)
    @mock.patch('wahwah.client.WahwahConnection',
                spec=WahwahConnection)
    def client_creation_filled_test(self, mc_con, mc_sta, mc_list):
        mo_con = mc_con.return_value
        mo_list = mc_list.return_value
        cli = Client(auth_token='My-token', server='beta',
                     allow_unregistered=True)
        # Check empty properties
        self.assertIsNone(cli.login_info)
        self.assertIsNone(cli.user_info)
        self.assertIsNone(cli.user_id)
        # Check not empty properties
        self.assertIsNotNone(cli.auth_token)
        self.assertIsNotNone(cli.server)
        self.assertIsNotNone(cli.allow_unregistered)
        self.assertIsNotNone(cli.user_favorites)
        self.assertIsNotNone(cli.user_stations)
        self.assertIsNotNone(cli.wahwah)
        self.assertIsNotNone(cli._Client__thread)
        # Check connection
        mc_con.assert_called_once_with(WAHWAH_SERVER['beta']['server'],
                                            timeout=7)
        self.assertEqual(cli.wahwah, mo_con)
        mo_con.reset.assert_called_once_with()
        # Check server
        self.assertIsInstance(cli.server, basestring)
        self.assertEqual(cli.server, 'beta')
        # Check registered
        self.assertIsInstance(cli.allow_unregistered, bool)
        self.assertTrue(cli.allow_unregistered)
        # Check lists
        mc_list.assert_any_call(cli, 'favorites')
        mc_list.assert_any_call(cli, 'stations')
        self.assertEqual(mo_list, cli.user_favorites)
        self.assertEqual(mo_list, cli.user_stations)


    @mock.patch('wahwah.client.WahwahUserList',
                spec=WahwahUserList)
    @mock.patch('wahwah.client.WahwahStation',
                spec=WahwahStation)
    @mock.patch('wahwah.client.WahwahConnection',
                spec=WahwahConnection)
    def client_creation_filled_custom_backend_test(self, mc_con, mc_sta, mc_list):
        cli = Client(auth_token='My-token', backend_uri='www.senzari.com',
                     allow_unregistered=True, backend_id='98794626873')

        self.assertEqual(cli.server, 'custom')
        self.assertEqual(cli.backend_uri, 'www.senzari.com')
        self.assertEqual(cli.backend_id, '98794626873')


    @mock.patch('wahwah.client.WahwahUserList',
                spec=WahwahUserList)
    @mock.patch('wahwah.client.WahwahStation',
                spec=WahwahStation)
    @mock.patch('wahwah.client.WahwahConnection',
                spec=WahwahConnection)
    def client_initialization_empty_test(self, mc_con, mc_sta, mc_list):
        empty_cli = Client()
        empty_cli.login_info = object()
        empty_cli.user_info = object()
        empty_cli.user_id = object()
        empty_cli.user_favorites = object()
        empty_cli.user_stations = object()
        empty_cli._get_login = MagicMock(side_effect=WahwahException)
        empty_cli._get_user_info = MagicMock(side_effect=WahwahException)
        empty_cli._check_status = MagicMock(side_effect=WahwahException)
        mc_list.reset_mock()

        try:
            empty_cli.re_set_client()
        except WahwahException:
            pass

        self.assertEqual(len(mc_list.mock_calls), 2)
        self.assertIsNone(empty_cli.login_info)
        self.assertIsNone(empty_cli.user_info)
        self.assertIsNone(empty_cli.user_id)
        self.assertIsNotNone(empty_cli.user_favorites)
        self.assertIsNotNone(empty_cli.user_stations)

    def client_gets_login_info_empty_test(self):
        self.mo_con.request.return_value = {}
        ret = self.empty_cli._get_login()
        self.assertEqual(ret, self.empty_cli.login_info)
        self.assertEqual(self.empty_cli.auth_token, None)
        self.mo_con.request.assert_called_once_with(
            'GET', "/api/1.0/account/login/?access_token=")

        self.mo_con.reset_mock()

        self.mo_con.request.return_value = {}
        ret = self.filled_cli._get_login()
        self.assertEqual(ret, self.filled_cli.login_info)
        self.assertEqual(self.filled_cli.auth_token, 'My-token')
        self.mo_con.request.assert_called_once_with(
            'GET', "/api/1.0/account/login/?access_token=My-token")

    def client_gets_user_info_empty_test(self):
        self.mo_con.request.return_value = {}
        ret = self.empty_cli._get_user_info()
        self.assertEqual(ret, self.empty_cli.user_info)
        self.assertEqual(None, self.empty_cli.user_id)
        self.mo_con.request.assert_called_once_with(
            'GET', '/api/1.0/account/')

        self.mo_con.reset_mock()

        self.mo_con.request.return_value = {}
        ret = self.filled_cli._get_user_info()
        self.assertEqual(ret, self.filled_cli.user_info)
        self.assertEqual(None, self.filled_cli.user_id)
        self.mo_con.request.assert_called_once_with(
            'GET', '/api/1.0/account/')

    def client_search_checks_status_first_test(self):
        SuccessException = type(b'SuccessException', (Exception,), {})
        self.mo_con.request.side_effect = self.fail
        self.filled_cli._check_status = MagicMock(side_effect=SuccessException)
        self.empty_cli._check_status = MagicMock(side_effect=SuccessException)

        try:
            print self.empty_cli.search_artist('artist')
        except SuccessException:
            pass
        except:
            self.fail('_check_status() not called before request')

        try:
            print self.filled_cli.search_artist('artist')
        except SuccessException:
            pass
        except:
            self.fail('_check_status() not called before request')