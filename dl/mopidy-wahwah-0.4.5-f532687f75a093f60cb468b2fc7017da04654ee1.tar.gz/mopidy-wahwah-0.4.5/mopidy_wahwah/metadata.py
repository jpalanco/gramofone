from __future__ import unicode_literals, absolute_import

import ConfigParser
import logging

from mopidy.backends.base import BaseMetadataProvider
from mopidy.utils import path
from time import time

logger = logging.getLogger("mopidy.backends.wahwah")


class WahwahMetadataProvider(BaseMetadataProvider):
    def set(self, uri, key, value):
        data = uri.split(':', 1)[1]
        if "user" == data and key == "auth_token":
            self.backend.wahwah.set_token(value)
        elif ":" in data:
            id = data.split(':', 1)[1]
            sta = self.backend.wahwah.get_station(id=id)
            if "wahwah:tempo" in key:
                sta.tempo = value
            if "wahwah:popularity" in key:
                sta.popularity = value
            if "wahwah:discover" in key:
                sta.discovery = value
            if "wahwah:similarity" in key:
                sta.similarity = value
        return True

    def get(self, uri, key):
        data = uri.split(':', 1)[1]
        res = {}
        if "user" == data:
            if not key:
                key = ["token", "name", "status"]
            if "token" in key:
                ans = self.backend.wahwah._wahwah.auth_token
                res["token"] = True if ans else False
            if "name" in key:
                if self.backend.wahwah._wahwah.user_info:
                    res["name"] = self.backend.wahwah._wahwah.user_info['name']
                else:
                    res["name"] = None
            if "status" in key:
                if self.backend.wahwah._wahwah.user_info:
                    res["status"] = self.backend.wahwah._wahwah.user_info['status']
                else:
                    res['status'] = None
        elif "service" == data:
            if not key:
                key = ["status", "code", 'appid', 'last_code']
            if "status" in key:
                res['status'] = self.backend.wahwah.status
            if 'last_code' in key:
                last_code = self.backend.wahwah.last_error
                if last_code[1] is not None:
                    last_code = (last_code[0], time() - last_code[1])
                res['last_code'] = last_code
            if "code" in key and key != "last_code":
                res['code'] = self.backend.wahwah.status_code
            if 'appid' in key:
                res['appid'] = self.backend.wahwah.appid
        elif ":" in data:
            if not key:
                key = ['wahwah:tempo',
                       'wahwah:popularity',
                       'wahwah:discovery',
                       'wahwah:similarity',
                       ]
            id = data.split(':', 1)[1]
            sta = self.backend.wahwah.get_station(id=id)
            if "wahwah:tempo" in key:
                res["wahwah:tempo"] = sta.tempo
            if "wahwah:popularity" in key:
                res["wahwah:popularity"] = sta.popularity
            if "wahwah:discovery" in key:
                res["wahwah:discovery"] = sta.discovery
            if "wahwah:similarity" in key:
                res["wahwah:similarity"] = sta.similarity
        return res

    def raise_event(self, origin, method, uri):
        if origin == "audiod" and method == "set_auth_token":
            self.backend.wahwah.status = 'login'


    def config(self, uri):
        mopidy_config = ConfigParser.RawConfigParser()
        fp = path.expand_path(b'$XDG_CONFIG_DIR/mopidy/mopidy.conf')
        mopidy_config.read(fp)

        if not mopidy_config.has_option('wahwah', 'auth_token'):
            logger.warning("Called config() with no auth_token!!!")
            mopidy_config.set('wahwah', 'auth_token', '')

        token = mopidy_config.get('wahwah', 'auth_token')
        self.backend.wahwah.set_token(token)
