from __future__ import unicode_literals, absolute_import

import urllib
import logging

from . import WAHWAH_SERVER, WAHWAH_TIMEOUT
from .connection import WahwahConnection
from .list import WahwahUserList
from .station import WahwahStation
from wahwah.exceptions import WahwahNotLogged
import uuid
from threading import Thread, Event
from weakref import WeakSet


logger = logging.getLogger("wahwah.client")



class Client(object):
    """ This is the object that holds the session connection, really handled by
    :class:`WahwahConnection`. Only one client object for each user should be
    created.

    It is responsible of handling the user authentication process, and has all
    the calls that imply client-level API. It generates :class:`WahwahStation`
    to make the rest of the calls to the API.

    **CARE**: Client and Stations created by it share the same connection, and
    thus, the same session_id. Concurrent requests to Wahwah cannot be done
    from the same client object.
    """

    def __init__(self, auth_token=None, server='prod', allow_unregistered=False,
                 backend_uri=None, backend_id=None):
        """ On creation, logs in the client and in case the auth_token is not
        valid, logs the client as anonymous.

        It automatically calls :meth:`_get_login` and :meth:`_get_user_info`.

        :param auth_token: The Facebook authentication token for Wahwah App
        :type auth_token: str or None
        """
        self.allow_unregistered = allow_unregistered
        self.auth_token = auth_token
        if backend_uri and backend_id:
            self.server = 'custom'
            self.backend_uri = backend_uri
            self.backend_id = backend_id
        else:
            self.server = server
            self.backend_uri = WAHWAH_SERVER[server]['server']
            self.backend_id = WAHWAH_SERVER[server]['id']

        self.wahwah = WahwahConnection(self.backend_uri,
                                           timeout=WAHWAH_TIMEOUT)
        self.login_info = None
        self.user_info = None
        self.user_id = None
        self.user_favorites = WahwahUserList(self, "favorites")
        self.user_stations = WahwahUserList(self, "stations")
        self.wahwah.reset()

        self._station_pool = WeakSet()
        self.__thread = Thread(target=self._thread_run, name='WahwahBind')
        self.__thread.daemon = True
        self._event_queue = Event()
        self.__thread.start()

    def _add_station_to_pool(self, station):
        if not self.__thread:
            self.__thread = Thread(target=self._thread_run, name='WahwahBind')
            self.__thread.daemon = True
            self.__thread.start()
        self._station_pool.add(station)

    def _thread_run(self):
        while True:
            self._event_queue.wait()
            self._event_queue.clear()
            for station in self._station_pool.copy():
                try:
                    station._job_executor()
                except Exception as e:
                    logger.exception("Internal error on WahwahBind. %r", e)
        self.__thread = None

    def re_set_client(self):
        logger.debug("Re setting client...")
        self.login_info = None
        self.user_info = None
        self.user_id = None
        self.user_favorites = WahwahUserList(self, "favorites")
        self.user_stations = WahwahUserList(self, "stations")
        self.play_id = uuid.uuid4()
        self.wahwah.reset()

        # Failable calls should be here
        self._get_login()
        self._get_user_info()
        self._check_status()

    def _get_login(self):
        """ It is in charge of logging the client with :param:`auth_token`.

        It will be taking the authorization token returned by the API. It will
        also create the attribute :attr:`login_info` with the data returned by
        the API, in the form of::

            {
                "session_hash": "085ec8748b54fb7853b6024bd6acdbced9baebdc",
                "session_id": "15d4a36bf98f860517da36458aa453bb",
                "user_status": "not user"
            }

        :param auth_token: The facebook token to log the user with
        :type auth_token: str or None
        """
        data = self.wahwah.request("GET", "/api/1.0/account/login/?access_token=" +
                            (self.auth_token or ''))
        if 'access_token' in data:
            self.auth_token = data['access_token']
        self.login_info = data
        return data

    def _get_user_info(self):
        """ Gets the user information that the API has access to.

        It will create the attribute :attr:`user_info` with the data returned
        from the API::

            {
                "username": "Anonymous",
                "subscriptions_count": 0,
                "current_station": "",
                "stations_count": 0,
                "session_key": "15d4a36bf98f860517da36458aa453bb",
                "friends_following_count": 0,
                "id": null,
                "geo_country": {},
                "friends_following_me_count": 0,
                "location": "",
                "facebook_id": "",
                "email": "",
                "user_agent": null,
                "status": "ANON",
                "geo_city": {},
                "is_active": true,
                "stations_shared_count": 0,
                "screen_name": "Anonymous",
                "birthday_year": 1900,
                "favourites_count": 0,
                "name": "Anonymous",
                "language": "",
                "gender": "Unknown",
                "current_station_slug": "",
                "avatar": "",
                "country": ""
            }
        """
        data = self.wahwah.request("GET", "/api/1.0/account/")
        self.user_info = data
        if 'facebook_id' in data:
            self.user_id = data['facebook_id']
        return data

    def _check_status(self, connection_too=False):
        if self.allow_unregistered:
            logger.debug("Allowing unregistered..")
            return
        if not self.user_info:
            logger.debug("No user info, retrying...")
            self.re_set_client()
        if connection_too:
            self.wahwah.close()
            self.wahwah.connect()
        if self.user_info['status'] == 'ANON':
            self.wahwah.close()
            self.wahwah.connect()
            logger.debug("User info, but ANON")
            raise WahwahNotLogged()
        return

    def get_station(self, artist_id=None, station_id=None):
        assert bool(station_id) != bool(artist_id), \
            "between station_id and artist_id only one must be set"

        self._check_status()

        if station_id:
            body = '{"station_id":"%s"}' % station_id
        else:
            body = '{"artist_id":"%s"}' % artist_id

        sta = WahwahStation(self)
        sta._create_station(body)
        self._add_station_to_pool(sta)
        return sta

    def search_artist(self, keywords):
        """ Triggers a search in the Wahwah API with those keywords. In case of
        using an slug, it will be probably returned too, but within the list.

            [{'artist': u'Alejandra Guzm\xe1n',
              'id': 'ee1a5c9f-a6b5-11e0-b446-00251188dd67',
              'popularity': 'None',
              'resource_uri': u'',
              'slug': 'alejandra-guzman',
              'track': u'',
              'type': 'ARTIST',
              'value': 'ee1a5c9f-a6b5-11e0-b446-00251188dd67'},
             {'artist': u'Alejandro Fern\xe1ndez',
              'id': '93d04b30-b677-6f7c-e5a1-2c86aec4db93',
              'popularity': 'None',
              'resource_uri': u'',
              'slug': 'alejandro-fernandez',
              'track': u'',
              'type': 'ARTIST',
              'value': '93d04b30-b677-6f7c-e5a1-2c86aec4db93'},
             {'artist': 'Peter Alexander',
              'id': '9dde58fd-f76f-da22-b7a8-41f1820bfa44',
              'popularity': 'None',
              'resource_uri': u'',
              'slug': 'peter-alexander',
              'track': u'',
              'type': 'ARTIST',
              'value': '9dde58fd-f76f-da22-b7a8-41f1820bfa44'}]

        :param keywords: The string to use as keywords
        :type keywords: str
        :rtype: list of artists
        """
        q = urllib.urlencode({"q": keywords})
        self._check_status()
        data = self.wahwah.request("GET", "/api/1.0/stations/create/?" + q)
        return data

    def get_track_inputs(self):
        data = self.wahwah.request("GET", "/api/1.0/track_inputs/")
        self._track_inputs = data
        return data

    track_inputs = property(get_track_inputs)
