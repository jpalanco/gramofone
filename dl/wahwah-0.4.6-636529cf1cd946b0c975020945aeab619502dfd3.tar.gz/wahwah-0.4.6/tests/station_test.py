from __future__ import absolute_import, unicode_literals

import mock
import unittest
import wahwah
from wahwah.station import WahwahStation
from httplib import HTTPConnection
from wahwah.exceptions import WahwahStatusError
from threading import Event
from tests import get_track_sequence, get_track_1, processed_track_1


class ClientForTesting(wahwah.Client):
    wahwah = wahwah.connection.WahwahConnection('')
    play_id = 'my-play-id'
    _event_queue = Event()


class TestStationDataInitializationAndUse(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        sta = WahwahStation(cli)
        self.station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }
        sta._parse_station(self.station_creation_info)

        self.mo_cli = cli
        self.station = sta

    def test_station_parse_station_variables(self):
        self.assertEqual(
            self.station.name,
            self.station_creation_info['name'])
        self.assertEqual(
            self.station.id,
            self.station_creation_info['id'])
        self.assertEqual(
            self.station._artist_id,
            self.station_creation_info['artist_id'])
        self.assertEqual(
            self.station.session_id,
            self.station_creation_info['station_session_id'])
        self.assertEqual(self.station._data, self.station_creation_info)

    def test_same_station_comparison(self):
        sta2 = WahwahStation(self.mo_cli)
        sta2._parse_station(self.station_creation_info)

        self.assertEqual(self.station, sta2)


class TestStationCreation(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        self.station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        mo_req = cli.wahwah.request
        mo_req.return_value = self.station_creation_info
        sta = WahwahStation(cli)
        sta._parse_station = mock.MagicMock()

        self.mo_req = mo_req
        self.station = sta
        self.mo_parse_station = sta._parse_station

    def test_station_create_station_from_artist_id(self):
        self.station._create_station(
            '{"artist_id": "4f1a171e-1182-8cc6-b67a-f4959353349c"}')

        self.mo_req.called_once_with('POST',
             '/api/1.0/stations/',
             '{"artist_id": "4f1a171e-1182-8cc6-b67a-f4959353349c"}')
        self.mo_parse_station.assert_called_once_with(self.station_creation_info)

    def test_station_create_station_from_station_id(self):
        self.station._create_station(
            '{"station_id": "82ae54da-827e-11e3-99a2-12313d01a993"}')

        self.mo_req.called_once_with('POST',
             '/api/1.0/stations/',
             '{"station_id": "82ae54da-827e-11e3-99a2-12313d01a993"}')
        self.mo_parse_station.assert_called_once_with(self.station_creation_info)


class TestStationTrackRequests(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        cli.play_id = 'my-play-id'
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)

        self.station = sta
        self.mo_req = cli.wahwah.request

    def test_station_first(self):
        self.station._first()
        self.mo_req.assert_called_once_with('GET',
            '/api/1.0/stations/82ae54da-827e-11e3-99a2-12313d01a993/' +
            'a9c0433fda63890b241fc2de05df386d667e3632/' +
            '?action=first&audio_format=mp3&client_id=1355&playid=my-play-id')

    def test_station_next(self):
        self.station._next(duration=40)
        self.mo_req.assert_called_once_with('GET',
            '/api/1.0/stations/82ae54da-827e-11e3-99a2-12313d01a993/' +
            'a9c0433fda63890b241fc2de05df386d667e3632/' +
            '?action=next&audio_format=mp3&client_id=1355&playid=my-play-id' +
            '&duration=40')

    def test_station_error(self):
        self.station._error(duration=40)
        self.mo_req.assert_called_once_with('GET',
            '/api/1.0/stations/82ae54da-827e-11e3-99a2-12313d01a993/' +
            'a9c0433fda63890b241fc2de05df386d667e3632/' +
            '?action=error&audio_format=mp3&client_id=1355&playid=my-play-id' +
            '&duration=40')


class TestStationTrackGatherProcess(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)
        gt_mock = mock.MagicMock()
        ssl_mock = mock.MagicMock()

        sta._gather_track = gt_mock
        sta._set_skip_limit = ssl_mock

        self.gather_track_mock = gt_mock
        self.set_skip_limit_mock = ssl_mock
        self.station = sta

    def test_process_gather_sets_first_if_zero_job(self):
        g_sentinel = 'gather sentinel'
        self.gather_track_mock.return_value = g_sentinel
        self.station._first_time = False

        res = self.station._process_gather_track(0, 0, False)

        self.assertTrue(self.station._first_time)
        self.gather_track_mock.assert_called_once_with(0, False)
        self.assertEqual(g_sentinel, res)

    def test_process_gather_sets_skip_and_returns_response(self):
        g_sentinel = 'gather sentinel'
        self.gather_track_mock.return_value = g_sentinel

        res = self.station._process_gather_track(0, 0, False)

        self.set_skip_limit_mock.assert_called_once_with(g_sentinel)
        self.assertEqual(res, g_sentinel)

    def test_process_gather_return_none_on_406_exception(self):
        self.gather_track_mock.side_effect = WahwahStatusError(406, 'Skip limit reached')

        res = self.station._process_gather_track(0, 0, False)

        self.assertIsNone(res)
        self.assertEqual(self.gather_track_mock.side_effect,
                         self.station.limit)
        self.set_skip_limit_mock.assert_called_once_with(
            exception=self.gather_track_mock.side_effect)

    def test_process_gather_return_none_on_status_error(self):
        self.gather_track_mock.side_effect = WahwahStatusError(400, 'Not allowed')

        res = self.station._process_gather_track(0, 0, False)

        self.assertIsNone(res)
        self.assertNotEqual(self.gather_track_mock.side_effect,
                         self.station.limit)
        self.set_skip_limit_mock.assert_called_once_with(
            exception=self.gather_track_mock.side_effect)

    def test_process_gather_exception_is_ignored(self):
        self.gather_track_mock.side_effect = Exception('Some exception')

        res = self.station._process_gather_track(0, 0, False)

        self.assertIsNone(res)
        self.assertNotEqual(self.gather_track_mock.side_effect,
                         self.station.limit)
        self.assertEqual(self.set_skip_limit_mock.call_count, 0)


class TestStationTrackGather(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        f_mock = mock.MagicMock()
        n_mock = mock.MagicMock()
        e_mock = mock.MagicMock()
        c_s_mock = mock.MagicMock()
        self.station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
        }

        sta = WahwahStation(cli)
        sta._first = f_mock
        sta._next = n_mock
        sta._error = e_mock
        sta._create_station = c_s_mock

        self.first_mock = f_mock
        self.next_mock = n_mock
        self.error_mock = e_mock
        self.create_station_mock = c_s_mock
        self.station = sta

    def test_station_gather_track_first_uncreated(self):
        self.station._gather_track(0, False)

        self.create_station_mock.assert_called_once_with(
                '{"station_id": "' + self.station.id + '"}')
        self.first_mock.assert_called_once_with()
        self.assertFalse(
            self.next_mock.mock_calls or
            self.error_mock.mock_calls
        )

    def test_station_gather_track_first_created(self):
        self.station.session_id = 'a9c0433fda63890b241fc2de05df386d667e3632'

        self.station._gather_track(0, False)

        self.first_mock.assert_called_once_with()
        self.assertFalse(
            self.create_station_mock.mock_calls or
            self.next_mock.mock_calls or
            self.error_mock.mock_calls
        )

    def test_station_gather_track_second_no_error(self):
        self.station.session_id = 'a9c0433fda63890b241fc2de05df386d667e3632'
        self.station._gather_track(0, False)
        self.first_mock.reset_mock()

        self.station._gather_track(0, False)

        self.next_mock.assert_called_once_with(duration=0)
        self.assertFalse(
            self.create_station_mock.mock_calls or
            self.first_mock.mock_calls or
            self.error_mock.mock_calls
        )

    def test_station_gather_track_second_with_error(self):
        self.station.session_id = 'a9c0433fda63890b241fc2de05df386d667e3632'
        self.station._gather_track(0, False)
        self.first_mock.reset_mock()

        self.station._gather_track(0, True)

        self.error_mock.assert_called_once_with(duration=0)
        self.assertFalse(
            self.create_station_mock.mock_calls or
            self.first_mock.mock_calls or
            self.next_mock.mock_calls
        )

class TestStationProcessTracks(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)
        rptt_mock = mock.MagicMock()

        sta._response_parse_to_tracks = rptt_mock

        self.response_parse_to_tracks_mock = rptt_mock
        self.station = sta

    def test_proces_tracks_enumerates_from_request_counter(self):
        self.response_parse_to_tracks_mock.return_value = [1, 2, 3, 4]
        self.station._request_counter += 1

        res = self.station._process_tracks('some_data')

        self.response_parse_to_tracks_mock.assert_called_once_with('some_data')
        self.assertDictEqual(res, {1:1, 2:2, 3:3, 4:4})


class TestStationValidateTracks(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        cu_mock = mock.MagicMock()
        aj_mock = mock.MagicMock()
        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)
        sta._check_uri = cu_mock
        sta._add_job = aj_mock

        self.station = sta
        self.check_uri_mock = cu_mock
        self.add_job_mock = aj_mock

    def test_validate_track_on_success(self):
        self.check_uri_mock.return_value = {'tracks': True}

        ret = self.station._validate_track(1, {'uri':'nanai'})

        self.assertTrue(ret)
        self.check_uri_mock.assert_called_once_with('nanai')
        self.assertEqual(self.add_job_mock.call_count, 0)

    def test_validate_track_on_failure(self):
        self.check_uri_mock.return_value = None

        ret = self.station._validate_track(1, {'uri': 'nanai'})

        self.assertFalse(ret)
        self.check_uri_mock.assert_called_once_with('nanai')
        self.add_job_mock.assert_called_once_with(1, (True, 0))


class TestStationSkipLimit(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)
        self.station = sta

    def test_station_after_create_has_not_skip_limit(self):
        self.assertFalse(self.station._get_skip_limit())

    def test_station_skip_limit_by_skip_count_no_duration(self):
        '''
        This test should ignore the skip count because it doesn't know when it
        should allow the next() to be carried on.

        Maybe later we should start by doing this more correctly, and triggering
        a request in theese cases.
        '''
        response_data = { 'meta': {
            'skip_limit': 5,
            'skip_count': 3,
        }}
        self.station._set_skip_limit(response_data)
        self.assertFalse(self.station._get_skip_limit())

        response_data['meta']['skip_count'] = 4
        self.station._set_skip_limit(response_data)
        self.assertFalse(self.station._get_skip_limit())

        response_data['meta']['skip_count'] = 5
        self.station._set_skip_limit(response_data)
        self.assertFalse(self.station._get_skip_limit())

    def test_station_skip_limit_by_skip_count_with_duration(self):
        response_data = {
            'meta': {
            'skip_limit': 5,
            'skip_count': 3,
            },
            'track': {'duration': 20}
        }
        self.station._set_skip_limit(response_data)
        self.assertFalse(self.station._get_skip_limit())

        # TODO: make this assert to False
        response_data['meta']['skip_count'] = 4
        self.station._set_skip_limit(response_data)
        self.assertTrue(self.station._get_skip_limit())

        response_data['meta']['skip_count'] = 5
        self.station._set_skip_limit(response_data)
        self.assertTrue(self.station._get_skip_limit())

    def test_station_skip_limit_by_exception_first(self):
        self.station._set_skip_limit(exception=Exception())
        self.assertFalse(self.station._get_skip_limit())

    def test_station_skip_limit_by_exception_later(self):
        response_data = {
            'meta': {
                'skip_limit': 5,
                'skip_count': 5,
            },
            'track': {'duration': 20}
        }

        self.station._set_skip_limit(response_data)
        self.station._set_skip_limit(exception=Exception())
        self.assertTrue(self.station._get_skip_limit())


class TestStationParseTracks(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        sta = WahwahStation(cli)

        self.station = sta

    def test_track_parsing_all_fields(self):
        get_track = get_track_1
        get_track_result = [
            {
                'title': 'Track 1 is correct',
                'uri': 'http://track.com/1/good',
                'length': 1,
                'art_slug' : 'artist-slug',
                'art_name': 'artist-id',
                'alb_name': 'Correct',
            },
            {
                'title': "Track 2 is not correct",
                'uri': 'http://track.com/2/bad',
                'length': 1,
                'art_slug' : 'artist-slug',
                'art_name': 'artist-id',
                'alb_name': 'Failing',
            },
            {
                'title': "Track 3 is correct",
                'uri': 'http://track.com/3/good',
                'length': 1,
                'art_slug' : 'artist-slug',
                'art_name': 'artist-id',
                'alb_name': 'Correct',
            },
            {
                'title': "Track 4 is not correct",
                'uri': 'http://track.com/4/bad',
                'length': 1,
                'art_slug' : 'artist-slug',
                'art_name': 'artist-id',
                'alb_name': 'Failing',
            }
        ]
        res = self.station._response_parse_to_tracks(get_track)
        self.assertEqual(get_track_result, res)


class TestStationJobManagers(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        sta = WahwahStation(cli)

        self.station = sta

    def test_job_adds_data_correctly(self):
        self.assertFalse(self.station._job_queue)

        self.station._add_job(1, (False, 0))
        self.assertEqual(self.station._job_queue, {1:(False, 0)})

    def test_job_add_logics(self):
        self.station._add_job(1, (False, 0))
        self.station._add_job(1, (True, 0))

        self.assertEqual(self.station._job_queue, {1:(False, 0)})

    def test_job_selector(self):
        self.station._add_job(1, (False, 0))
        jobs = self.station._job_selector()
        self.assertNotIn(1, jobs)

        self.station._add_job(0, (False, 0))
        jobs = self.station._job_selector()
        self.assertEqual(jobs.keys(), [0])

        self.station._track_counter = 1
        jobs = self.station._job_selector()
        self.assertEqual(jobs.keys(), [0, 1])

        self.station._add_job(2, (False, 0))
        jobs = self.station._job_selector()
        self.assertEqual(jobs.keys(), [0, 1])


class TestStationJobExecutor(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }
        pgt_mock = mock.MagicMock()
        pt_mock = mock.MagicMock()
        vt_mock = mock.MagicMock()
        utq_mock = mock.MagicMock()

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)
        sta._process_gather_track = pgt_mock
        sta._process_tracks = pt_mock
        sta._validate_track = vt_mock
        sta._update_track_queue = utq_mock

        self.station = sta
        self.process_gather_track_m = pgt_mock
        self.process_tracks_m = pt_mock
        self.validate_track_m = vt_mock
        self.update_track_queue_m = utq_mock

    # Helper functions for simulating flows
    def validate_track_effect(self, num, track):
        if 'good' in track['uri']:
            return True
        elif 'bad' in track['uri']:
            return False

    def test_first_time_flow(self):
        # 0 and 2 good; 1 and 3 bad
        self.process_tracks_m.return_value = processed_track_1
        self.validate_track_m.side_effect = self.validate_track_effect
        self.station._request_counter = 1

        self.station._add_job(0, (False, 0))
        self.station._job_executor()

        self.process_gather_track_m.assert_called_once_with(0, 0, False)
        self.process_tracks_m.assert_called_once_with(
            self.process_gather_track_m.return_value
        )
        self.assertEqual(self.validate_track_m.call_count, 4)
        self.assertEqual(self.update_track_queue_m.call_count, 2)

        # Extract the call args
        tracks = []
        for call in self.update_track_queue_m.call_args_list:
            args, kwargs = call
            print args, kwargs
            if args:
                num = args[0]
            else:
                num = kwargs.pop()
            tracks.append(int(num))
        self.assertEqual(tracks, [1, 3])

    def test_flow_on_process_gather_track_does_not_return(self):
        self.process_gather_track_m.return_value = None
        self.station._add_job(0, (False, 0))
        self.station._job_executor()

    def test_job_executor_correctly_calls_process_gather_track(self):
        self.station._add_job(0, (False, 50))
        self.station._job_executor()
        self.process_gather_track_m.assert_called_once_with(0, 50, False)
        self.process_gather_track_m.reset_mock()
        self.station._track_counter = 2

        self.station._add_job(1, (True, 100))
        self.station._job_executor()
        self.process_gather_track_m.assert_called_once_with(1, 100, True)

    def test_station_on_error_not_skiplimit(self):
        pass

class TestStationTrackFlows(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }
        cli.play_id = 'my-play-id'

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)

        self.station = sta
        self.mo_req = cli.wahwah.request

    @unittest.skip("Test shouldn't test that many things at once")
    @mock.patch('wahwah.station.HTTPConnection', spec=HTTPConnection)
    def invalid_test_station_first_gets_track_itself(self, check_m):
        # Change effect of requests, either for get_track() as for checking tracks
        self.mo_req.side_effect = self.get_track_sequence_effect
        http_obj = check_m.return_value
        http_obj.request.side_effect = self.check_uri_effect
        http_obj.getresponse.side_effect = self.check_uri_effect

        self.station.get_track()
        self.mo_req.assert_called_once_with('GET',
            '/api/1.0/stations/82ae54da-827e-11e3-99a2-12313d01a993/' +
            'a9c0433fda63890b241fc2de05df386d667e3632/' +
            '?action=first&audio_format=mp3&client_id=1355&playid=my-play-id')

    def test_gettrack_starts_by_adding_job_zero_and_waiting(self):
        self.station._job_executor = mock.MagicMock()
        self.station._track_queue_updated = mock.MagicMock()
        self.station.get_track()
        self.assertEqual(self.station._job_executor.call_count, 0)
        self.station._track_queue_updated.assert_has_calls(
            [mock.call.clear(),
             mock.call.wait(timeout=5),
             mock.call.clear()])

    # Helper functions for simulating flows
    def check_uri_effect(self, method=None, path=None, **kwargs):
        if method or path or kwargs:
            if 'good' in path:
                self.should_return_good = True
            else:
                self.should_return_good = False
        else:
            if self.should_return_good:
                return self.status_response
            else:
                return None

    status_response = type(b'Response', (object,), {'status': 200})

    def get_track_sequence_effect(self, method, path):
        self.get_track_sequence = get_track_sequence
        if method != 'GET':
            raise WahwahStatusError(400, 'Method wrong')
        response = self.get_track_sequence.pop(0)
        if '1' in response['track']['url'] and 'first' not in path:
            self.get_track_sequence.insert(0, response)
            raise WahwahStatusError(400, 'First song not first')
        return response


class TestStationSettings(unittest.TestCase):
    def setUp(self):
        cli = mock.MagicMock(spec=ClientForTesting)
        station_creation_info = {
            'id': '82ae54da-827e-11e3-99a2-12313d01a993',
            'name': 'Alesana Radio',
            'artist_id': '4f1a171e-1182-8cc6-b67a-f4959353349c',
            'station_session_id': 'a9c0433fda63890b241fc2de05df386d667e3632',
        }
        cli.play_id = 'my-play-id'

        sta = WahwahStation(cli)
        sta._parse_station(station_creation_info)

        self.station = sta
        self.mo_req = cli.wahwah.request

    def test_settings_retrieve_does_not_trigger_two_requests(self):
        self.station._get_settings()
        self.mo_req.assert_called_once_with('GET', '/api/1.0/stations/%s/settings/' %
            self.station.id)
        self.mo_req.reset_mock()
        self.station._get_settings()
        self.assertFalse(self.mo_req.mock_calls)

    def test_setting_set_and_retrieve_triggers_request(self):
        self.station._get_settings()
        self.mo_req.reset_mock()

        self.station._set_settings('my_id', 'my_val')
        self.mo_req.assert_called_once_with('POST', '/api/1.0/stations/%s/settings/' %
            self.station.id, body=b'{"my_id": "my_val"}')
        self.mo_req.reset_mock()

        self.station._get_settings()
        self.assertTrue(self.mo_req.mock_calls)

    def test_get_set_tempo(self):
        m_set_get = mock.MagicMock()
        self.station._get_settings = m_set_get
        self.station._set_settings = m_set_get

        self.station._settings['tempo'] = None
        ret = self.station.tempo
        m_set_get.assert_called_once_with()
        self.assertIsNone(ret)
        m_set_get.reset_mock()

        self.station._settings['tempo'] = '0'
        ret = self.station.tempo
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'off')
        m_set_get.reset_mock()

        self.station._settings['tempo'] = '33'
        ret = self.station.tempo
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'low')
        m_set_get.reset_mock()

        self.station._settings['tempo'] = '66'
        ret = self.station.tempo
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'medium')
        m_set_get.reset_mock()

        self.station._settings['tempo'] = '100'
        ret = self.station.tempo
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'high')
        m_set_get.reset_mock()

        self.station.tempo = 'off'
        m_set_get.assert_called_once_with('tempo', '0')
        m_set_get.reset_mock()

        self.station.tempo = 'low'
        m_set_get.assert_called_once_with('tempo', '33')
        m_set_get.reset_mock()

        self.station.tempo = 'medium'
        m_set_get.assert_called_once_with('tempo', '66')
        m_set_get.reset_mock()

        self.station.tempo = 'high'
        m_set_get.assert_called_once_with('tempo', '100')
        m_set_get.reset_mock()

    def test_get_set_discovery(self):
        m_set_get = mock.MagicMock()
        self.station._get_settings = m_set_get
        self.station._set_settings = m_set_get

        self.station._settings['discovery'] = None
        ret = self.station.discovery
        m_set_get.assert_called_once_with()
        self.assertIsNone(ret)
        m_set_get.reset_mock()

        self.station._settings['discovery'] = 'off'
        ret = self.station.discovery
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'off')
        m_set_get.reset_mock()

        self.station._settings['discovery'] = 'low'
        ret = self.station.discovery
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'low')
        m_set_get.reset_mock()

        self.station._settings['discovery'] = 'medium'
        ret = self.station.discovery
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'medium')
        m_set_get.reset_mock()

        self.station._settings['discovery'] = 'high'
        ret = self.station.discovery
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'high')
        m_set_get.reset_mock()

        self.station.discovery = 'off'
        m_set_get.assert_called_once_with('discovery', 'off')
        m_set_get.reset_mock()

        self.station.discovery = 'low'
        m_set_get.assert_called_once_with('discovery', 'low')
        m_set_get.reset_mock()

        self.station.discovery = 'medium'
        m_set_get.assert_called_once_with('discovery', 'medium')
        m_set_get.reset_mock()

        self.station.discovery = 'high'
        m_set_get.assert_called_once_with('discovery', 'high')
        m_set_get.reset_mock()

    def test_get_set_popularity(self):
        m_set_get = mock.MagicMock()
        self.station._get_settings = m_set_get
        self.station._set_settings = m_set_get

        self.station._settings['popularity'] = None
        ret = self.station.popularity
        m_set_get.assert_called_once_with()
        self.assertIsNone(ret)
        m_set_get.reset_mock()

        self.station._settings['popularity'] = 'off'
        ret = self.station.popularity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'off')
        m_set_get.reset_mock()

        self.station._settings['popularity'] = 'low'
        ret = self.station.popularity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'low')
        m_set_get.reset_mock()

        self.station._settings['popularity'] = 'medium'
        ret = self.station.popularity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'medium')
        m_set_get.reset_mock()

        self.station._settings['popularity'] = 'high'
        ret = self.station.popularity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'high')
        m_set_get.reset_mock()

        self.station.popularity = 'off'
        m_set_get.assert_called_once_with('popularity', 'off')
        m_set_get.reset_mock()

        self.station.popularity = 'low'
        m_set_get.assert_called_once_with('popularity', 'low')
        m_set_get.reset_mock()

        self.station.popularity = 'medium'
        m_set_get.assert_called_once_with('popularity', 'medium')
        m_set_get.reset_mock()

        self.station.popularity = 'high'
        m_set_get.assert_called_once_with('popularity', 'high')
        m_set_get.reset_mock()


    def test_get_set_similarity(self):
        m_set_get = mock.MagicMock()
        self.station._get_settings = m_set_get
        self.station._set_settings = m_set_get

        self.station._settings['similarity'] = None
        ret = self.station.similarity
        m_set_get.assert_called_once_with()
        self.assertIsNone(ret)
        m_set_get.reset_mock()

        self.station._settings['similarity'] = 'off'
        ret = self.station.similarity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'off')
        m_set_get.reset_mock()

        self.station._settings['similarity'] = 'low'
        ret = self.station.similarity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'low')
        m_set_get.reset_mock()

        self.station._settings['similarity'] = 'medium'
        ret = self.station.similarity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'medium')
        m_set_get.reset_mock()

        self.station._settings['similarity'] = 'high'
        ret = self.station.similarity
        m_set_get.assert_called_once_with()
        self.assertEqual(ret, 'high')
        m_set_get.reset_mock()

        self.station.similarity = 'off'
        m_set_get.assert_called_once_with('similarity', 'off')
        m_set_get.reset_mock()

        self.station.similarity = 'low'
        m_set_get.assert_called_once_with('similarity', 'low')
        m_set_get.reset_mock()

        self.station.similarity = 'medium'
        m_set_get.assert_called_once_with('similarity', 'medium')
        m_set_get.reset_mock()

        self.station.similarity = 'high'
        m_set_get.assert_called_once_with('similarity', 'high')
        m_set_get.reset_mock()

    def test_exception_on_get(self):
        self.mo_req.side_effect = WahwahStatusError(406)
        with self.assertRaises(WahwahStatusError):
            self.station._get_settings()
        self.assertEqual(self.mo_req.call_count, 1)

        self.mo_req.side_effect = None
        _ = self.station.tempo
        _ = self.station.discovery
        _ = self.station.popularity
        _ = self.station.similarity

        self.assertEqual(self.mo_req.call_count, 2)