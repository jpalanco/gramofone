from __future__ import unicode_literals

import os
import logging
import unittest


logging.basicConfig(level=logging.DEBUG)


def path_to_data_dir(name):
    if not isinstance(name, bytes):
        name = name.encode('utf-8')
    path = os.path.dirname(__file__)
    path = os.path.join(path, b'data')
    path = os.path.abspath(path)
    return os.path.join(path, name)

get_track_sequence = [
    {
        'track': {
            'title': 'Track 1 is correct',
            'url': 'http://track.com/1/good',
            'duration': 1,
            'artist_slug' : 'artist-slug',
            'artist': 'artist-id',
            'album': 'Correct',
        },
        'next_tracks': [
            {
                'title': "Track 2 is not correct",
                'url': 'http://track.com/2/bad',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Failing',
            },
            {
                'title': "Track 3 is correct",
                'url': 'http://track.com/3/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 4 is not correct",
                'url': 'http://track.com/4/bad',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Failing',
            },
        ]
    },
    {
        'track': {
            'title': "Track 2 is not correct",
            'url': 'http://track.com/2/bad',
            'duration': 1,
            'artist_slug' : 'artist-slug',
            'artist': 'artist-id',
            'album': 'Failing',
        },
        'next_tracks': [
            {
                'title': "Track 3 is correct",
                'url': 'http://track.com/3/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 4 is not correct",
                'url': 'http://track.com/4/bad',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Failing',
            },
            {
                'title': "Track 5 is correct",
                'url': 'http://track.com/5/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
        ]
    },
    {
        'track': {
            'title': "Track 3 is correct",
            'url': 'http://track.com/3/good',
            'duration': 1,
            'artist_slug' : 'artist-slug',
            'artist': 'artist-id',
            'album': 'Correct',
        },
        'next_tracks': [
            {
                'title': "Track 4 is not correct",
                'url': 'http://track.com/4/bad',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Failing',
            },
            {
                'title': "Track 5 is correct",
                'url': 'http://track.com/5/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 6 is correct",
                'url': 'http://track.com/6/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
        ]
    },
    {
        'track': {
            'title': "Track 4 is not correct",
            'url': 'http://track.com/4/bad',
            'duration': 1,
            'artist_slug' : 'artist-slug',
            'artist': 'artist-id',
            'album': 'Failing',
        },
        'next_tracks': [
            {
                'title': "Track 5 is correct",
                'url': 'http://track.com/5/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 6 is correct",
                'url': 'http://track.com/6/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 7 is correct",
                'url': 'http://track.com/7/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
        ]
    },
    {
        'track': {
                'title': "Track 5 is correct",
                'url': 'http://track.com/5/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
        'next_tracks': [
            {
                'title': "Track 6 is correct",
                'url': 'http://track.com/6/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 7 is correct",
                'url': 'http://track.com/7/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
            {
                'title': "Track 8 is correct",
                'url': 'http://track.com/8/good',
                'duration': 1,
                'artist_slug' : 'artist-slug',
                'artist': 'artist-id',
                'album': 'Correct',
            },
        ]
    },
]

processed_track_sequence = [
    {
        '1': {
            'title': 'Track 1 is correct',
            'uri': 'http://track.com/1/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '2': {
            'title': "Track 2 is not correct",
            'uri': 'http://track.com/2/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },
        '3': {
            'title': "Track 3 is correct",
            'uri': 'http://track.com/3/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '4': {
            'title': "Track 4 is not correct",
            'uri': 'http://track.com/4/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },

    },
    {
        '2': {
            'title': "Track 2 is not correct",
            'uri': 'http://track.com/2/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },
        '3': {
            'title': "Track 3 is correct",
            'uri': 'http://track.com/3/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '4': {
            'title': "Track 4 is not correct",
            'uri': 'http://track.com/4/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },
        '5': {
            'title': "Track 5 is correct",
            'uri': 'http://track.com/5/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },

    },
    {
        '3': {
            'title': "Track 3 is correct",
            'uri': 'http://track.com/3/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '4': {
            'title': "Track 4 is not correct",
            'uri': 'http://track.com/4/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },
        '5': {
            'title': "Track 5 is correct",
            'uri': 'http://track.com/5/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '6': {
            'title': "Track 6 is correct",
            'uri': 'http://track.com/6/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
    },
    {
        '4': {
            'title': "Track 4 is not correct",
            'uri': 'http://track.com/4/bad',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Failing',
        },
        '5': {
            'title': "Track 5 is correct",
            'uri': 'http://track.com/5/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '6': {
            'title': "Track 6 is correct",
            'uri': 'http://track.com/6/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '7': {
            'title': "Track 7 is correct",
            'uri': 'http://track.com/7/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
    },
    {
        '5': {
            'title': "Track 5 is correct",
            'uri': 'http://track.com/5/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '6': {
            'title': "Track 6 is correct",
            'uri': 'http://track.com/6/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '7': {
            'title': "Track 7 is correct",
            'uri': 'http://track.com/7/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
        '8': {
            'title': "Track 8 is correct",
            'uri': 'http://track.com/8/good',
            'length': 1,
            'art_slug' : 'artist-slug',
            'art_name': 'artist-id',
            'alb_name': 'Correct',
        },
    },
]


get_track_1 = get_track_sequence[0]
get_track_2 = get_track_sequence[1]
get_track_3 = get_track_sequence[2]
get_track_4 = get_track_sequence[3]
get_track_5 = get_track_sequence[4]

processed_track_1 = processed_track_sequence[0]
processed_track_2 = processed_track_sequence[1]
processed_track_3 = processed_track_sequence[2]
processed_track_4 = processed_track_sequence[3]
processed_track_5 = processed_track_sequence[4]