import logging

__version__ = '0.4.6'

log_format = "%(levelname)-8s %(asctime)s [%(process)d:" + \
             "%(threadName)s] %(name)s\n  %(message)s"
logging.basicConfig(format=log_format)


WAHWAH_SERVER = {
    "dev": {
        "server": "",
        "id": "179112635484679"
    },
    "beta": {
        "server": "beta.senzari.com",
        "id": "412502805505493"
    },
    "qa": {
        "server": "",
        "id": "212527535452849"
    },
    "prod": {
        "server": "www.senzari.com",
        "id": "305500226127280"
    }
}

MUSIC_STORE_TIMEOUT=5
REFRESH_MAX_RATE = 100
WAHWAH_TIMEOUT=7


from client import Client  # noqa
