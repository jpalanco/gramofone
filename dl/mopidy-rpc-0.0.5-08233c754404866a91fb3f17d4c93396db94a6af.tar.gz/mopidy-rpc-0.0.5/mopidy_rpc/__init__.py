from __future__ import unicode_literals

import os

import mopidy
import time
from mopidy import config, exceptions, ext

__version__ = '0.0.5'

class RPCExtension(ext.Extension):

    name = "Mopidy-RPC"
    ext_name = 'rpc'
    version = __version__

    def get_default_config(self):
        conf_file = os.path.join(os.path.dirname(__file__), 'ext.conf')
        return config.read(conf_file)

    def get_config_schema(self):
        schema = super(RPCExtension, self).get_config_schema()
        schema['hostname'] = config.Hostname()
        schema['port'] = config.Port()
        schema['user'] = config.Secret()
        schema['password'] = config.Secret()
        return schema

    def validate_environment(self):
        try:
            import SocketServer  # noqa
        except ImportError as e:
            raise exceptions.ExtensionError('SocketServer library not found', e)

    def get_frontend_classes(self):
        from .actor import RPCFrontend
        return [RPCFrontend]
