from __future__ import unicode_literals, absolute_import

import logging

from mopidy.audio import PlaybackState
from mopidy.backends.base import BaseTracklistProvider
from mopidy.core import listener
from mopidy.frontends.mpd.exceptions import MpdPermissionError


logger = logging.getLogger("mopidy.backends.wahwah")


def is_station(tl_track, artist_name=None):
    artist = next(iter(tl_track.track.artists)).name
    if artist_name and artist != artist_name:
        return False
    return tl_track.track.name == artist + " Radio"


class WahwahTracklistProvider(BaseTracklistProvider):
    def add(self, tracklist, tracks, at_position, uri):
        logger.debug("add(%r,%r,%r)", tracks, at_position, uri)
        logger.debug("Add's starting tracklist")
        self.__print_tracklist(tracklist._tl_tracks)
        if not at_position:
            at_position = -1
        if not tracklist._tl_tracks:
            logger.debug("Add's returning tracklist")
            self.__print_tracklist(tracklist._tl_tracks)
            return
        ttl = tracklist._tl_tracks[at_position]
        if is_station(ttl):
            if tracks[0].uri == ttl.track.uri:
                logger.debug("Add's returning tracklist")
                self.__print_tracklist(tracklist._tl_tracks)
                return [ttl]

    def remove(self, tracklist, tl_tracks):
        logger.debug("remove(%r)", tl_tracks)
        removed = list()
        for tl_track in tl_tracks:
            if is_station(tl_track):
                try:
                    check = tracklist._tl_tracks.index(tl_track) - 1
                except ValueError:
                    continue
                station_uri = tl_track.track.uri
                while check >= 0:
                    tlt = tracklist._tl_tracks[check]
                    if station_uri == tlt.track.uri:
                        del tracklist._tl_tracks[check]
                        removed.append(tl_track)
                        check -= 1
                    else:
                        break
                del tracklist._tl_tracks[check]
                removed.append(tl_track)
            elif not "wahwah:" in tl_track.track.uri:
                del tracklist._tl_tracks[check]
                removed.append(tl_track)
        if removed:
            tracklist._version += 1
            if (not tracklist._tl_tracks or
                    tracklist.core.playback.current_tl_track not in
                    tracklist._tl_tracks):
                self.backend.playback.stop()
                tracklist.core.playback.state = PlaybackState.STOPPED
                logger.debug('Triggering track playback ended event')
                listener.CoreListener.send(
                    'track_playback_ended',
                    tl_track=tracklist.core.playback.current_tl_track,
                    time_position=self.backend.playback.get_time_position())
            tracklist.core.playback.current_tl_track = None
            tracklist._trigger_tracklist_changed()
        return removed

    def move(self, tracklist, start, end, to_position):
        logger.debug("move(%r, %r, %r)", start, end, to_position)
        not_our_bussines = True
        moving = tracklist._tl_tracks[start:end]
        to_create = False  # It is really a list
        before = None

        self._check_tracklist(tracklist)

        for tl_track in moving:
            if "wahwah:" in tl_track.track.uri:
                not_our_bussines = False
                logger.debug("Moving our bussiness")
                if is_station(tl_track):
                    logger.debug("Moving one station")
                    sta_uri = tl_track.track.uri
                    start += 1
                    while True:
                        start -= 1
                        if start == -1:
                            start = 0
                            break
                        tl_track = tracklist._tl_tracks[start]
                        if sta_uri != tl_track.track.uri:
                            start += 1
                            break
                elif len(moving) == 1:
                    logger.debug("Just moving one song ours: " + repr(moving))
                    artist_uri = next(iter(moving[0].track.artists)).uri
                    logger.debug("artist_uri = '%s'" % artist_uri)
                    to_create = self.backend.library.lookup(artist_uri)

        if to_create:
            logger.debug("After processing, to create '%s'" % (repr(
                         to_create)))
        else:
            logger.debug("After processing, moving %d:%d" % (start, end))

        if to_position >= 1:
            to_position += 1
            before = tracklist._tl_tracks[to_position - 1]

        if before:
            while not (is_station(before) or
                       not "wahwah:" in before.track.uri):
                logger.debug("Before is not station or other")
                to_position += 1
                before = tracklist._tl_tracks[to_position - 1]
                not_our_bussines = False

        if not_our_bussines:
            logger.debug("Not our bussiness")
            return False

        logger.debug("After processing, destination is %d" % to_position)

        if to_create:
            after_uri = None
            if to_position < len(tracklist._tl_tracks):
                after_uri = tracklist._tl_tracks[to_position].track.uri
            if to_create[0].uri in (before.track.uri, after_uri):
                return True
            else:
                tracklist._add(to_create, to_position)
                logger.debug("Created on move %s" % repr(to_create))
        else:
            logger.debug("Moving track(s)")
            new_tl_tracks = tracklist._tl_tracks[:start] + \
                tracklist._tl_tracks[end:]
            for tl_track in tracklist._tl_tracks[start:end]:
                new_tl_tracks.insert(to_position, tl_track)
                to_position += 1
            tracklist._tl_tracks = new_tl_tracks
            tracklist._increase_version()
        self._check_tracklist(tracklist)
        return True

    def next_track(self, tracklist, tl_track):
        logger.debug("next(%r)", tl_track)
        self.backend.playback.update_duration()
        logger.debug("Next's starting tracklist")
        self.__print_tracklist(tracklist._tl_tracks)
        id = tl_track.track.uri.split(':')[2]
        if self.backend.wahwah.check_limit(id=id):
            logger.debug("check_limit == True!")
            ex = MpdPermissionError(index=0, command='next')
            ex.message = "Skip limit reached"
            raise ex
        ret = self.__get_track(tracklist, tl_track)
        logger.debug("Next's response: %r", ret)
        return ret

    def eot_track(self, tracklist, tl_track):
        logger.debug("eot(%r)", tl_track)
        self.backend.playback.update_duration()
        logger.debug("EOT's starting tracklist")
        self.__print_tracklist(tracklist._tl_tracks)
        ret = self.__get_track(tracklist, tl_track)
        self._check_time_difference(tl_track)
        logger.debug("EOT's response: %r", ret)
        return ret

    def __get_track(self, tracklist, tl_track):
        index = tracklist._tl_tracks.index(tl_track)
        # If am not being called from mpd
        if self.backend.wahwah.status != 'error' and \
           self.backend.wahwah.check_available():
            station = self.backend.library.lookup(tl_track.track.uri)
        else:
            logger.debug("Found status (%r!='error' and available==%r) to be False",
                         self.backend.wahwah.status,
                         self.backend.wahwah.check_available())
            return None

        self.backend.playback.skip_raise = True
        # If none behind, for sure we will need to add one
        if not (len(tracklist._tl_tracks) > index + 1):
            logger.debug("Adding returned station to playlist, this is last")
            tracklist._add(station, index + 1)

        next_tl_track = tracklist._tl_tracks[index + 1]
        # In case the next track is from the same source, ours
        if tl_track.track.uri == next_tl_track.track.uri:
            logger.debug("Already available track is enough")
            return next_tl_track
        # In case user is clicking next while on a radio station,
        else:
            logger.debug("Adding returned station to playlist")
            tracklist._add(station, index + 1)

        return tracklist._tl_tracks[index + 1]

    def _check_time_difference(self, tl_track):
        real = self.backend.playback.get_time_position() // 1000
        stated = tl_track.track.length // 1000
        if abs(real - stated) > stated / 25:
            logger.info('Time difference is %d seconds', real - stated)
            logger.debug('Time difference, abs(%d - %d) > %d/25',
                        real, stated, stated)
            self.backend.playback.had_error += 1

    def previous_track(self, tracklist, tl_track):
        logger.debug("previous()")
        return None

    def mark_playing(self, tracklist, tl_track):
        self._check_tracklist(tracklist)

        track = self.backend.playback.track
        index = tracklist._tl_tracks.index(tl_track)
        while not is_station(tracklist._tl_tracks[index]):
            index += 1

        new_track = track.copy(uri=tl_track.track.uri)
        new_tl_track = tracklist._add([new_track], index)[0]
        tracklist.core.playback.current_tl_track = new_tl_track
        if len(tracklist._tl_tracks) > \
                self.backend.config["wahwah"]["max_playlist"]:
            while len(tracklist._tl_tracks) > \
                    self.backend.config["wahwah"]["max_playlist"]:
                del tracklist._tl_tracks[0]
            tracklist._increase_version()
        return True

    def mark_unplayable(self, tracklist, tl_track):
        return False

    def _check_tracklist(self, tracklist):
        check = len(tracklist._tl_tracks) - 1
        recheck = False
        rerecheck = False
        station = None
        station_uri = None

        # Check we haven't finished
        while check >= -1:
            if check <= -1:
                if recheck:
                    if rerecheck:
                        logger.error("ERROR, recheck is not the same")
                    else:
                        rerecheck = True
                        recheck = False
                        check = len(tracklist._tl_tracks) - 1
                else:
                    return
            # Next element to check in the list
            tlt = tracklist._tl_tracks[check]
            # Element's station uri
            uri = tlt.track.uri

            if "wahwah:" not in tlt.track.uri:
                station = None
                station_uri = None
                check -= 1
                continue

            if is_station(tlt):
                if station and station_uri == tlt.track.uri and station != tlt:
                    logging.warning("Removing duplicate station: %r", station)
                    tracklist._remove([tlt])  # Care with list arguments
                    check -= 1
                    recheck = True
                    continue
                station = tlt
                station_uri = tlt.track.uri
                check -= 1
                continue

            if uri != station_uri:
                missing = self.backend.library.lookup(uri)
                check += 1
                tracklist._add(missing, check)
                recheck = True
                logging.warning("Station has been added: %r", missing)
                continue

            if uri == station_uri:
                check -= 1
                continue

            logger.error("There is a case not taken into account!!!")
            check -= 1

    def __print_tracklist(self, tracks):
        logger.debug("Tracklist START")
        for pos, t in enumerate(tracks):
            logger.debug("\t%d: %s -- %s[%d]", pos, t.track.uri,
                                          t.track.name, t.tlid)
        logger.debug("Tracklist END")
