from __future__ import unicode_literals

import re
from setuptools import setup, find_packages


def get_version(filename):
    content = open(filename).read()
    metadata = dict(re.findall("__([a-z]+)__ = '([^']+)'", content))
    return metadata['version']


setup(
    name='Mopidy-WahWah',
    version=get_version('mopidy_wahwah/__init__.py'),
    url='https://github.com/fonlabs/mopidy-wahwah',
    license='Privative',
    author='Javier Domingo Cansino',
    author_email='javier.domingo@fon.com',
    description='Wahwah plugin for Mopidy',
    long_description=open('README').read(),
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'simplejson>=3.3.0',
        'wahwah>=0.4.0',
    ],
    entry_points={
        b'mopidy.ext': [
            'wahwah = mopidy_wahwah:WahwahExtension',
        ],
    },
    classifiers=[
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2',
        'Topic :: Multimedia :: Sound/Audio :: Players',
    ],
)
