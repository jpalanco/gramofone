from __future__ import unicode_literals, absolute_import

import os

from mopidy import ext, config
from mopidy.exceptions import ExtensionError

__version__ = '0.4.5'


class WahwahExtension(ext.Extension):
    dist_name = "Wahwah Extension"
    ext_name = "wahwah"

    def get_backend_classes(self):
        from .actor import WahwahBackend
        return [WahwahBackend]

    def get_config_schema(self):
        schema = super(WahwahExtension, self).get_config_schema()
        schema['auth_token'] = config.Secret(optional=True)
        schema['max_playlist'] = config.Integer(minimum=2)
        schema['allow_unregistered'] = config.Boolean()
        schema['host'] = config.String(optional=True)
        schema['facebook_id'] = config.String(optional=True)
        return schema

    def get_default_config(self):
        conf_file = os.path.join(os.path.dirname(__file__), 'ext.conf')
        return config.read(conf_file)

    def validate_environment(self):
        try:
            from wahwah import Client  # noqa
        except ImportError as e:
            raise ExtensionError("Wahwah client API library is not present", e)
