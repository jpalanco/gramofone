from __future__ import absolute_import, unicode_literals


import unittest
import mock

# TODO:

class ListTest(unittest.TestCase):
    def list_unlogged_fails_test(self):
        # TODO: Test that when client is not logged
        # gathering the list fails
        pass