******
Wahwah
******

This is a wahwah API that uses a binding created for Fon. It has been developed
to be as minimal as possible. Using it should be straight-forward, but this
documentation has been developed in case it isn't.

Usage
=====

Contents:

.. toctree::
   :maxdepth: 2

   client


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

