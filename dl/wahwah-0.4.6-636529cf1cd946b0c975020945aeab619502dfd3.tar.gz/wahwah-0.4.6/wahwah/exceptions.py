from __future__ import absolute_import, unicode_literals

import logging

logger = logging.getLogger('wahwah.exceptions')


class WahwahException(Exception):
    pass

class WahwahStatusError(WahwahException):
    def __init__(self, status, *args):
        WahwahException.__init__(self, status, *args)
        self.status = status

class WahwahNotConnected(WahwahException):
    pass

class WahwahNotLogged(WahwahException):
    pass

class WahwahTimeout(WahwahNotConnected):
    def __init__(self, time, *args):
        WahwahException.__init__(self, time, *args)
        self.status = time