from __future__ import unicode_literals

import re
from setuptools import setup, find_packages


def get_version(filename):
    content = open(filename).read()
    metadata = dict(re.findall("__([a-z]+)__ = '([^']+)'", content))
    return metadata['version']


setup(
    name='Mopidy-RPC',
    version=get_version('mopidy_rpc/__init__.py'),
    url='https://github.com/fonlabs/mopidy-rpc',
    license='Privative',
    author='Iker Perez de Albeniz',
    author_email='iker.perez@fon.com',
    description='RPC plugin for Mopidy fon integration',
    long_description=open('README').read(),
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
    ],
    entry_points={
        b'mopidy.ext': [
            'rpc = mopidy_rpc:RPCExtension',
        ],
    },
    classifiers=[
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2',
    ],
)
